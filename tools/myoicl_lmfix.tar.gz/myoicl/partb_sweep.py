# Copyright (c) 2026 MyoICL authors. MIT License.
"""Find ANY zero-label configuration with positive gain, cheaply.

574 collapsed 55.39 -> 99.85. That run used the worst possible setting of
every knob at once: no filter (100% of windows at 56 CER), lr 1e-3, 200 steps,
and -- my error -- it evaluated the STUDENT while building an EMA teacher and
never using it. Mean Teacher exists precisely because the student is unstable
under noisy pseudo-labels; the teacher is what you deploy.

This script decodes each user ONCE, then sweeps adaptation configurations over
the same cached pseudo-labels, so a 20-cell sweep costs one decode plus twenty
short finetunes. Knobs:

    filter      which subset to train on (from partb2's validated arms)
    lr          1e-5 .. 1e-3
    steps       20 .. 200
    target      student | ema-teacher      <- the fix for 574's error
    scope       all norm affine | input BN affine only

Reports every cell, including the collapses, because "which configurations
collapse" is itself the ablation the paper needs (the plan's §3.4 asks for
exactly this row).
"""
from __future__ import annotations

import argparse
import copy
import itertools
import json
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


def norm_params(model, scope="all"):
    ps = []
    for name, m in model.named_modules():
        if not isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.LayerNorm,
                              nn.GroupNorm)):
            continue
        if scope == "inputbn" and "frontend.0" not in name:
            continue
        for p in (m.weight, m.bias):
            if p is not None:
                ps.append(p)
    return ps


def adapt(model, samples, keep, pseudo_ids, cs, dev, steps, lr, ema,
          scope, batch_size=4):
    """Returns (student, teacher). Both are deep copies; caller picks."""
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate

    student = copy.deepcopy(model)
    teacher = copy.deepcopy(model)
    for p in teacher.parameters():
        p.requires_grad_(False)
    for p in student.parameters():
        p.requires_grad_(False)
    ps = norm_params(student, scope)
    for p in ps:
        p.requires_grad_(True)
    if not ps or not keep:
        return student, teacher

    sub = [samples[i] for i in keep]
    ids = [pseudo_ids[i] for i in keep]
    opt = torch.optim.Adam(ps, lr=lr)
    student.train()
    done = 0
    while done < steps:
        order = np.random.permutation(len(sub))
        for s in range(0, len(order), batch_size):
            chunk = [int(j) for j in order[s:s + batch_size]]
            b = windowed_collate([sub[j] for j in chunk])
            x = b["inputs"].to(dev)
            em = student(x).float()
            tgt, tlen = [], []
            for j in chunk:
                t = [c for c in ids[j] if c != cs.null_class]
                tgt.append(t); tlen.append(len(t))
            if not tgt or min(tlen) == 0:
                continue
            T = torch.zeros(len(tgt), max(tlen), dtype=torch.long)
            for r, t in enumerate(tgt):
                T[r, : len(t)] = torch.tensor(t, dtype=torch.long)
            in_len = torch.full((len(tgt),), em.shape[0], dtype=torch.long)
            loss = nn.functional.ctc_loss(
                em[:, : len(tgt)], T.to(dev), in_len.to(dev),
                torch.tensor(tlen).to(dev), blank=cs.null_class,
                zero_infinity=True)
            if not torch.isfinite(loss):
                continue
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(ps, 1.0)
            opt.step()
            with torch.no_grad():
                for pt, psd in zip(teacher.parameters(),
                                   student.parameters()):
                    pt.mul_(ema).add_(psd.detach(), alpha=1 - ema)
            done += 1
            if done >= steps:
                break
    student.eval(); teacher.eval()
    return student, teacher


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--user", required=True)
    ap.add_argument("--cal-windows", type=int, default=128)
    ap.add_argument("--filters", nargs="+",
                    default=["conf_nb>q90", "conf_nb>q75",
                             "consistent+conf75"])
    ap.add_argument("--lrs", type=float, nargs="+",
                    default=[1e-5, 3e-5, 1e-4])
    ap.add_argument("--steps", type=int, nargs="+", default=[30, 100])
    ap.add_argument("--scopes", nargs="+", default=["all", "inputbn"])
    ap.add_argument("--ema", type=float, default=0.99)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import yaml
    from emg2qwerty.charset import charset as charset_fn
    from emg2qwerty.data import LabelData
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate
    from .eval_qwerty import eval_user
    from .metrics import CERAccumulator, greedy_ctc_decode
    from .model import build_model
    from .partb2 import augmented_views, window_stats
    from .pretrained import load_official_backbone
    from .tta_floor import unlabelled_windows

    cfg = yaml.safe_load(open(a.config))
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()
    np.random.seed(a.seed); torch.manual_seed(a.seed)

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, cfg.get("init_backbone_from"))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    u = a.user
    cal = unlabelled_windows(a.repo_root, a.data_root, u, a.cal_windows,
                             ea.window_length, ea.padding, a.seed)
    if not cal:
        raise SystemExit(f"[FATAL] no calibration windows for {u}")

    # ---- decode ONCE ---------------------------------------------------
    recs = []
    dl = DataLoader(cal, batch_size=4, shuffle=False,
                    collate_fn=windowed_collate)
    with torch.no_grad():
        for b in dl:
            x = b["inputs"].to(dev)
            em = model(x).float()
            lens = torch.full((em.shape[1],), em.shape[0], dtype=torch.long)
            g = greedy_ctc_decode(em, lens, blank=cs.null_class)
            views = [greedy_ctc_decode(model(v).float(), lens,
                                       blank=cs.null_class)
                     for v in augmented_views(x, 2, a.seed)]
            tg, tl = b["targets"].numpy(), b["target_lengths"].numpy()
            for n in range(em.shape[1]):
                r = dict(window_stats(em[:, n], int(lens[n]), cs.null_class))
                r["greedy"] = LabelData.from_labels(g[n]).text
                r["ids"] = list(map(int, g[n]))
                r["true"] = LabelData.from_labels(tg[: tl[n], n]).text
                r["consistent"] = all(
                    LabelData.from_labels(v[n]).text == r["greedy"]
                    for v in views)
                recs.append(r)

    def cer_of(idx, key="greedy"):
        acc = CERAccumulator()
        for i in idx:
            acc.update(recs[i][key], recs[i]["true"])
        return acc.cer

    N = len(recs)
    cq = np.quantile([r["conf_nb"] for r in recs], [0.5, 0.75, 0.9])
    sets = {
        "conf_nb>q50": [i for i in range(N) if recs[i]["conf_nb"] >= cq[0]],
        "conf_nb>q75": [i for i in range(N) if recs[i]["conf_nb"] >= cq[1]],
        "conf_nb>q90": [i for i in range(N) if recs[i]["conf_nb"] >= cq[2]],
        "consistent": [i for i in range(N) if recs[i]["consistent"]],
        "consistent+conf75": [i for i in range(N)
                              if recs[i]["consistent"]
                              and recs[i]["conf_nb"] >= cq[1]],
    }
    print(f"[{u}] {N} windows | raw pseudo-CER {cer_of(range(N)):.2f}")
    for k, v in sets.items():
        if v:
            print(f"   {k:>20}: n={len(v):<4d} keep={len(v)/N:5.1%} "
                  f"pseudo-CER {cer_of(v):6.2f}")

    base = eval_user(model, cs, u, a.repo_root, a.data_root, "A", ea, dev).cer
    print(f"[{u}] unadapted test CER {base:.2f}\n")

    rows = []
    ids_all = [r["ids"] for r in recs]
    grid = list(itertools.product(a.filters, a.lrs, a.steps, a.scopes))
    print(f"sweeping {len(grid)} cells (student and ema-teacher each)\n")
    for f, lr, st, sc in grid:
        keep = sets.get(f, [])
        if len(keep) < 4:
            continue
        stu, tea = adapt(model, cal, keep, ids_all, cs, dev, st, lr,
                         a.ema, sc)
        for tag, mdl in (("student", stu), ("ema", tea)):
            c = eval_user(mdl, cs, u, a.repo_root, a.data_root, "A", ea,
                          dev).cer
            rows.append({"filter": f, "lr": lr, "steps": st, "scope": sc,
                         "target": tag, "cer": c, "gain": base - c,
                         "kept": len(keep),
                         "pseudo_cer": cer_of(keep)})
            print(f"  {f:>18} lr={lr:<7.0e} steps={st:<4d} {sc:>7} "
                  f"{tag:>7}: CER {c:6.2f}  gain {base - c:+6.2f}",
                  flush=True)
        del stu, tea
        torch.cuda.empty_cache()

    rows.sort(key=lambda r: -r["gain"])
    print("\n=== TOP 5 ===")
    for r in rows[:5]:
        print(f"  gain {r['gain']:+6.2f} | {r['filter']} lr={r['lr']:.0e} "
              f"steps={r['steps']} {r['scope']} {r['target']} "
              f"(kept {r['kept']}, pseudo-CER {r['pseudo_cer']:.1f})")
    pos = [r for r in rows if r["gain"] > 0]
    print(f"\n  {len(pos)}/{len(rows)} cells have POSITIVE gain")
    if pos:
        b = rows[0]
        print(f"  BEST: {base:.2f} -> {b['cer']:.2f} ({b['gain']:+.2f}) "
              f"with zero labels")
    else:
        print("  no positive cell -- the pseudo-labels are too noisy at every "
              "setting; the filter, not the optimiser, is the bottleneck.")
    json.dump({"args": vars(a), "base": base, "rows": rows,
               "sets": {k: len(v) for k, v in sets.items()}},
              open(a.out, "w"), indent=1)
    print(f"\n[saved] {a.out}")


if __name__ == "__main__":
    main()
