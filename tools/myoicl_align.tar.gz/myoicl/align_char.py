# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part A stage 1: character-level supervised contrastive alignment with
cross-user positive pairs. This is the loss with our name on it.

THE IDEA, and where it comes from. CLISA (arXiv 2109.09559) showed on EEG
that if you form positive pairs from DIFFERENT SUBJECTS responding to the
same stimulus, one contrastive term buys both class separability and subject
invariance at once, worth +6.7 to +10.2 points there. The plan transplants
that to sEMG typing: user A's 'e' and user B's 'e' should land in the same
place in feature space, and nothing in the CTC objective asks for that.

Why this is not redundant with the normalisation family (RTN/RSG/ACM): those
act on the INPUT and remove amplitude, scale and electrode nuisance. This
acts on the REPRESENTATION GEOMETRY -- whether two users' embeddings of the
same character coincide. The EEG survey (arXiv 2604.27033) lists them as
separate families for that reason. Whether they are additive in practice is
exactly what our two-baseline table will measure, not assume.

CSIN (arXiv 2607.03783) carries a warning we take seriously: on EMG, triplet
loss alone and adversarial subject-confusion alone each gave negligible gain,
and only the combination worked. So a single metric term is not expected to
be sufficient on its own, and the adversarial arm stays on the roadmap.

MECHANICS.
  1. CTC forced alignment (torchaudio.functional.forced_align) turns the
     frame sequence into character segments -- using the TRUE labels, which
     is legitimate here because Part A is supervised training on the 96
     training users.
  2. Each segment is mean-pooled over encoder features into one character
     embedding.
  3. Supervised contrastive loss over those embeddings, with positives
     restricted to (or weighted toward) pairs from DIFFERENT users.
  4. A warm-up period trains CTC only: before the model can align, the
     segments are noise and the contrastive term would pull noise together.
"""
from __future__ import annotations

import torch
from torch import nn


def forced_align_segments(log_probs, targets, in_len, tgt_len, blank):
    """-> list of (start_frame, end_frame, char_id) for ONE utterance.

    log_probs (T, C) ; targets (L,) ; both already on cpu/gpu consistently.
    Falls back to an empty list if alignment is impossible (T < L).
    """
    import torchaudio.functional as AF

    T = int(in_len)
    L = int(tgt_len)
    if L == 0 or T < L:
        return []
    lp = log_probs[:T].unsqueeze(0)
    tg = targets[:L].unsqueeze(0).to(torch.int32)
    try:
        ali, _ = AF.forced_align(
            lp.float(), tg,
            torch.tensor([T], device=lp.device, dtype=torch.int32),
            torch.tensor([L], device=lp.device, dtype=torch.int32),
            blank=blank)
    except Exception:
        return []
    a = ali[0].tolist()
    segs, cur, start = [], None, 0
    for t, tok in enumerate(a):
        if tok != cur:
            if cur is not None and cur != blank and t > start:
                segs.append((start, t, int(cur)))
            cur, start = tok, t
    if cur is not None and cur != blank and len(a) > start:
        segs.append((start, len(a), int(cur)))
    return segs


def pool_segments(h, segs):
    """h (T, d) -> (n_seg, d) mean-pooled over each segment."""
    if not segs:
        return None
    out = [h[s:e].mean(0) for (s, e, _c) in segs]
    return torch.stack(out)


def supcon_cross_user(z, y, u, tau=0.1, cross_user_only=True,
                      same_user_weight=0.2):
    """Supervised contrastive loss with cross-user positives prioritised.

    z (M, d) L2-normalised ; y (M,) character ids ; u (M,) user ids.

    Positives are same-character pairs. With cross_user_only, a same-character
    pair from the SAME user contributes only `same_user_weight` of a normal
    positive -- the point of the loss is to pull DIFFERENT users' versions of
    a character together, and same-user positives are the easy case the CTC
    objective already handles.
    """
    M = z.shape[0]
    if M < 4:
        return z.sum() * 0.0
    sim = (z @ z.t()) / tau
    eye = torch.eye(M, dtype=torch.bool, device=z.device)
    sim = sim.masked_fill(eye, -1e4)

    same_y = y.unsqueeze(0) == y.unsqueeze(1)
    same_u = u.unsqueeze(0) == u.unsqueeze(1)
    pos = same_y & ~eye
    if cross_user_only:
        w = torch.where(same_u, torch.full_like(sim, same_user_weight),
                        torch.ones_like(sim))
        w = w * pos.float()
    else:
        w = pos.float()

    has_pos = w.sum(1) > 0
    if has_pos.sum() == 0:
        return z.sum() * 0.0
    logZ = torch.logsumexp(sim, dim=1, keepdim=True)
    log_p = sim - logZ
    loss = -(w * log_p).sum(1)[has_pos] / w.sum(1)[has_pos].clamp_min(1e-6)
    return loss.mean()


class CharAligner(nn.Module):
    """Projection head for the contrastive space (SimCLR-style, 2 layers)."""

    def __init__(self, d_in: int, d_out: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_in, d_in), nn.GELU(), nn.Linear(d_in, d_out))

    def forward(self, x):
        return nn.functional.normalize(self.net(x), dim=-1)


def char_align_loss(model, proj, h, log_probs, batch, cs, user_ids,
                    max_segs=512, tau=0.1, cross_user_only=True,
                    same_user_weight=0.2, min_len=2):
    """One call: align, pool, project, contrast.

    h (T, N, d) encoder features ; log_probs (T, N, C) ; batch from
    windowed_collate ; user_ids (N,) long.
    Returns (loss, n_segments, n_distinct_users_contributing).
    """
    T, N, _ = h.shape
    tg = batch["targets"].to(h.device)             # (Lmax, N)
    tl = batch["target_lengths"].to(h.device)
    embs, ys, us = [], [], []
    for n in range(N):
        segs = forced_align_segments(log_probs[:, n], tg[:, n], T,
                                     int(tl[n]), cs.null_class)
        segs = [s for s in segs if s[1] - s[0] >= min_len]
        if not segs:
            continue
        p = pool_segments(h[:, n], segs)
        embs.append(p)
        ys.append(torch.tensor([c for (_a, _b, c) in segs], device=h.device))
        us.append(torch.full((len(segs),), int(user_ids[n]),
                             device=h.device, dtype=torch.long))
    if not embs:
        return h.sum() * 0.0, 0, 0
    E = torch.cat(embs); Y = torch.cat(ys); U = torch.cat(us)
    if E.shape[0] > max_segs:
        idx = torch.randperm(E.shape[0], device=E.device)[:max_segs]
        E, Y, U = E[idx], Y[idx], U[idx]
    Z = proj(E)
    loss = supcon_cross_user(Z, Y, U, tau, cross_user_only, same_user_weight)
    return loss, int(E.shape[0]), int(U.unique().numel())
