# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part A stage 1 trainer: CTC + cross-user character contrastive (L_char).

Runs on the PLAIN official TDS, deliberately. Measuring our alignment on the
plain baseline is the clean read on our own contribution, and it does not
have to wait for the SplashNet arms to finish. The same code takes
--no-specnorm/--rtn later to produce the second column, "on top of the
strongest known normalisation", which is the column that answers "did you
compare to SOTA".

Gate A, from the plan: >= 1.5 CER absolute improvement on unseen users keeps
the two-loss route alive.

Two controls are built in, because a contrastive term that pulls SOMETHING
together will always lower its own loss whether or not it helps decoding:
  --shuffle-users   randomises the user id, destroying the cross-user
                    structure while keeping every other detail. If the gain
                    survives this, it never came from cross-user alignment.
  --w-char 0        the pure-CTC arm at identical budget and seed.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import time

import numpy as np
import torch
from torch import nn
from torch.utils.data import ConcatDataset, DataLoader, Dataset


class WithUser(Dataset):
    """Wrap a session dataset so every sample carries its user index."""

    def __init__(self, ds, uid: int):
        self.ds, self.uid = ds, uid

    def __len__(self):
        return len(self.ds)

    def __getitem__(self, i):
        return self.ds[i], self.uid


def collate_with_user(batch):
    from .episodes import windowed_collate

    samples = [b[0] for b in batch]
    uids = torch.tensor([b[1] for b in batch], dtype=torch.long)
    out = windowed_collate(samples)
    out["user_ids"] = uids
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--w-char", type=float, default=0.2)
    ap.add_argument("--tau", type=float, default=0.1)
    ap.add_argument("--char-warmup", type=int, default=8000,
                    help="CTC-only steps before L_char switches on; before "
                         "the model can align, the segments are noise and "
                         "the contrastive term would pull noise together")
    ap.add_argument("--cross-user-only", type=int, default=1)
    ap.add_argument("--same-user-weight", type=float, default=0.2)
    ap.add_argument("--max-segs", type=int, default=512)
    ap.add_argument("--shuffle-users", action="store_true",
                    help="CONTROL: randomise user ids, destroying the "
                         "cross-user structure and nothing else")
    # normalisation recipe passthrough (for the second column, later)
    ap.add_argument("--bands", type=int, default=0)
    ap.add_argument("--rtn", type=int, default=0)
    ap.add_argument("--no-specnorm", action="store_true")
    ap.add_argument("--window-length", type=int, default=8000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight-decay", type=float, default=1e-5)
    ap.add_argument("--max-steps", type=int, default=60000)
    ap.add_argument("--warmup", type=int, default=2000)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--eval-every", type=int, default=2000)
    ap.add_argument("--log-every", type=int, default=200)
    ap.add_argument("--num-workers", type=int, default=4)
    ap.add_argument("--bf16", action="store_true", default=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    from emg2qwerty.charset import charset as charset_fn
    from emg2qwerty.data import WindowedEMGDataset

    from .align_char import CharAligner, char_align_loss
    from .model import build_model
    from .qwerty_data import (group_by_user, load_user_sessions,
                              official_train_transform)
    from .splash import SplashFrontend
    from .train_splash import build_eval_windows, cer_on

    os.makedirs(a.out_dir, exist_ok=True)
    torch.manual_seed(a.seed); np.random.seed(a.seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()

    sess = load_user_sessions(a.repo_root, "generic", a.data_root)
    by_user = group_by_user(sess["train"])
    users = sorted(by_user)
    uidx = {u: i for i, u in enumerate(users)}
    print(f"[split] {len(users)} training users | "
          f"{len(sess['test'])} official test sessions", flush=True)

    front = SplashFrontend(n_bands_out=a.bands, use_rtn=bool(a.rtn),
                           use_acm=False).to(dev)
    cfg = {"model": {"version": 1, "frontend": "official",
                     "official_mlp_features": [384],
                     "freq_bins": front.out_freq_bins,
                     "num_bands": 2, "channels_per_band": 16,
                     "d_model": 768,
                     "tds_block_channels": [24, 24, 24, 24],
                     "tds_kernel_width": 32,
                     "use_residual_context": False}}
    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    if a.no_specnorm:
        model.frontend[0] = nn.Identity()
        print("[model] frontend[0] -> Identity (RTN replaces it)")
    proj = CharAligner(768).to(dev)
    print(f"[model] TDS {sum(p.numel() for p in model.parameters())/1e6:.2f}M "
          f"| proj {sum(p.numel() for p in proj.parameters())/1e6:.2f}M "
          f"| w_char={a.w_char} tau={a.tau} warmup={a.char_warmup} "
          f"cross_user_only={a.cross_user_only} "
          f"shuffle_users={a.shuffle_users}", flush=True)

    tf = official_train_transform()
    parts = []
    for u in users:
        for p in by_user[u]:
            parts.append(WithUser(
                WindowedEMGDataset(p, window_length=a.window_length,
                                   padding=(1800, 200), transform=tf,
                                   jitter=True), uidx[u]))
    ds = ConcatDataset(parts)
    print(f"[data] {len(ds)} windows over {len(parts)} sessions", flush=True)
    dl = DataLoader(ds, batch_size=a.batch, shuffle=True, drop_last=True,
                    num_workers=a.num_workers, collate_fn=collate_with_user,
                    persistent_workers=a.num_workers > 0, pin_memory=True)
    eval_test = build_eval_windows(sess["test"])

    params = list(model.parameters()) + list(proj.parameters())
    decay = [p for p in params if p.ndim > 1]
    nod = [p for p in params if p.ndim <= 1]
    opt = torch.optim.AdamW(
        [{"params": decay, "weight_decay": a.weight_decay},
         {"params": nod, "weight_decay": 0.0}], lr=a.lr, betas=(0.9, 0.98))

    def lr_at(s):
        if s < a.warmup:
            return s / max(a.warmup, 1)
        t = (s - a.warmup) / max(1, a.max_steps - a.warmup)
        return 0.5 * (1 + math.cos(math.pi * min(t, 1.0)))

    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_at)

    best, hist, run, seg_run, usr_run, t0 = float("inf"), [], [], [], [], time.time()
    step = 0
    model.train(); proj.train()
    while step < a.max_steps:
        for b in dl:
            x = front(b["inputs"].to(dev))
            uid = b["user_ids"].to(dev)
            if a.shuffle_users:
                uid = uid[torch.randperm(uid.shape[0], device=dev)]
            with torch.autocast(device_type=dev.type, dtype=torch.bfloat16,
                                enabled=a.bf16):
                h = model.tds(model.frontend(x))
                logits = model.classifier(h)
            h = h.float(); logits = logits.float()
            lp = logits.log_softmax(-1)
            in_len = torch.full((lp.shape[1],), lp.shape[0],
                                dtype=torch.long, device=dev)
            loss = nn.functional.ctc_loss(
                lp, b["targets"].transpose(0, 1).to(dev), in_len,
                b["target_lengths"].to(dev), blank=cs.null_class,
                zero_infinity=True)
            ns = nu = 0
            if a.w_char > 0 and step >= a.char_warmup:
                lc, ns, nu = char_align_loss(
                    model, proj, h, lp.detach(), b, cs, uid,
                    max_segs=a.max_segs, tau=a.tau,
                    cross_user_only=bool(a.cross_user_only),
                    same_user_weight=a.same_user_weight)
                if torch.isfinite(lc):
                    loss = loss + a.w_char * lc
            if not torch.isfinite(loss):
                continue
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(params, a.grad_clip)
            opt.step(); sched.step()
            run.append(float(loss)); seg_run.append(ns); usr_run.append(nu)
            step += 1

            if step % a.log_every == 0:
                print(f"step {step}/{a.max_steps} | loss {np.mean(run):.4f} "
                      f"| segs/step {np.mean(seg_run):.0f} | users/step "
                      f"{np.mean(usr_run):.1f} | lr "
                      f"{sched.get_last_lr()[0]:.2e} | "
                      f"{step/(time.time()-t0):.2f} it/s", flush=True)
                run, seg_run, usr_run = [], [], []
            if step % a.eval_every == 0:
                c = cer_on(model, front, eval_test, cs, dev, a.bf16)
                hist.append({"step": step, "test_cer": c})
                print(f"[val] step {step}: 8-test-user CER {c:.2f}", flush=True)
                st = {"model": model.state_dict(), "proj": proj.state_dict(),
                      "front": front.state_dict(), "cfg": cfg,
                      "args": vars(a), "step": step}
                torch.save(st, os.path.join(a.out_dir, "last.pt"))
                if c < best:
                    best = c
                    torch.save(st, os.path.join(a.out_dir, "best.pt"))
                    print(f"[val] new best {best:.2f}", flush=True)
                json.dump({"args": vars(a), "hist": hist, "best": best},
                          open(os.path.join(a.out_dir, "hist.json"), "w"),
                          indent=1)
            if step >= a.max_steps:
                break
    print(f"[done] best {best:.2f}")


if __name__ == "__main__":
    main()
