# Copyright (c) 2026 MyoICL authors. MIT License.
"""In-context conditioning that the decoder CANNOT bypass.

The failure of the previous design, stated precisely: the context was
PREPENDED to a causal transformer as extra tokens. Self-attention is free to
put ~zero weight on those tokens, and the training objective rewarded exactly
that -- a quarter of the steps had no context at all, and most of the rest
were solvable without it. Gradient descent found "ignore the context", and the
measured gain sat slightly BELOW zero: context read as noise.

The fix is structural, not another loss term. Here the context produces the
output layer itself:

    omega = g(context)                                  # (V, d)
    logits[t, v] = h[t] . omega[v]

There is NO static output matrix. If the context carries no information about
this episode, the model cannot name a single symbol -- the "ignore it"
solution does not exist in the hypothesis space. This is BraInCoRL's omega
(their Eq. 5) with a decoder swapped in for their voxel encoder.

Deliberate design points:
  * the set encoder has NO positional embedding: the context is a SET, so
    permuting the calibration examples cannot change the result;
  * omega is produced by V learned queries cross-attending over the context
    tokens, NOT squeezed through one pooled vector. A single d_z-dim vector
    would have to carry all V*d numbers of the mapping, and that bottleneck
    could fail the experiment for a reason that has nothing to do with the
    hypothesis under test;
  * the pairing (x_i, y_i) lives INSIDE one token, rather than being left for
    attention to discover across two separate bags -- the other thing the
    prefix design got wrong.
"""
from __future__ import annotations

import torch
from torch import nn


class SetContextEncoder(nn.Module):
    """Order-invariant encoder over labelled context pairs.

    Returns (tokens, z): per-example tokens (N, K, d) for the omega head to
    attend over, and a pooled summary (N, d_z) for FiLM-style conditioning.
    """

    def __init__(self, d_in: int, n_symbols: int, d_model: int = 128,
                 n_layers: int = 4, n_heads: int = 4, d_z: int = 128) -> None:
        super().__init__()
        self.proj_x = nn.Linear(d_in, d_model)
        self.proj_y = nn.Embedding(n_symbols, d_model)
        layer = nn.TransformerEncoderLayer(
            d_model, n_heads, d_model * 4, dropout=0.0,
            batch_first=True, norm_first=True, activation="gelu")
        self.enc = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d_model)
        self.to_z = nn.Linear(d_model, d_z)
        self.d_z = d_z

    def forward(self, cx: torch.Tensor, cy: torch.Tensor):
        """cx (N, K, d_in), cy (N, K) long. No positional embedding anywhere."""
        h = self.proj_x(cx) + self.proj_y(cy)
        h = self.norm(self.enc(h))                       # (N, K, d)
        return h, self.to_z(h.mean(dim=1))               # mean pool = set


class OmegaHead(nn.Module):
    """The output layer, generated entirely by the context.

    V learned queries cross-attend over the context tokens; the result IS the
    output weight matrix. With no context there is nothing to attend to and no
    weights to decode with -- which is the whole point.

    `static=True` builds a plain nn.Linear head instead. That mode exists only
    to construct the control arms of the experiment, the arms that must fail.
    """

    def __init__(self, d_model: int, n_out: int, d_z: int,
                 static: bool = False, n_heads: int = 4) -> None:
        super().__init__()
        self.n_out, self.d_model, self.static = n_out, d_model, static
        if static:
            self.head = nn.Linear(d_model, n_out)
            return
        self.queries = nn.Parameter(torch.randn(n_out, d_model) * 0.02)
        self.attn = nn.MultiheadAttention(d_model, n_heads, batch_first=True)
        self.q_norm = nn.LayerNorm(d_model)
        self.o_norm = nn.LayerNorm(d_model)
        self.bias = nn.Linear(d_z, n_out)
        self.scale = nn.Parameter(torch.tensor(1.0))

    def forward(self, h: torch.Tensor, tokens: torch.Tensor | None,
                z: torch.Tensor | None) -> torch.Tensor:
        """h (N, T, d); tokens (N, K, d); z (N, d_z) -> logits (N, T, n_out)."""
        if self.static:
            return self.head(h)
        n = h.shape[0]
        q = self.q_norm(self.queries).unsqueeze(0).expand(n, -1, -1)
        omega, _ = self.attn(q, tokens, tokens, need_weights=False)
        omega = self.o_norm(omega)                        # (N, V, d)
        logits = torch.einsum("ntd,nvd->ntv", h, omega) * self.scale
        return logits + self.bias(z).unsqueeze(1)


class FiLM(nn.Module):
    """Per-feature affine modulation of the trunk from z (bypassable extra)."""

    def __init__(self, d_model: int, d_z: int) -> None:
        super().__init__()
        self.to_gb = nn.Linear(d_z, 2 * d_model)
        nn.init.zeros_(self.to_gb.weight)
        nn.init.zeros_(self.to_gb.bias)              # starts as identity

    def forward(self, h: torch.Tensor, z: torch.Tensor) -> torch.Tensor:
        g, b = self.to_gb(z).chunk(2, dim=-1)
        return h * (1 + g).unsqueeze(1) + b.unsqueeze(1)


class ContextConditionedDecoder(nn.Module):
    """Small trunk + one of four ways of (not) using the context.

    mode:
      'omega'  -- output layer generated by the context      (the proposal)
      'film'   -- static head, context modulates features    (bypassable)
      'prefix' -- context prepended as tokens, static head   (what we built
                  before, and what returned zero gain)
      'static' -- no context at all                          (the floor)

    Note the trunk here is NOT causal. That makes the 'prefix' arm STRONGER
    than the emg2qwerty version was -- every query frame sees every context
    token, both directions. If prefix still loses, the conclusion is
    conservative.
    """

    def __init__(self, d_in: int, n_symbols: int, n_out: int,
                 d_model: int = 128, n_layers: int = 4, n_heads: int = 4,
                 d_z: int = 128, mode: str = "omega") -> None:
        super().__init__()
        assert mode in ("omega", "film", "static", "prefix")
        self.mode = mode
        self.inp = nn.Linear(d_in, d_model)
        layer = nn.TransformerEncoderLayer(
            d_model, n_heads, d_model * 4, dropout=0.0,
            batch_first=True, norm_first=True, activation="gelu")
        self.trunk = nn.TransformerEncoder(layer, n_layers)
        self.norm = nn.LayerNorm(d_model)
        # only build a context encoder for the modes that actually consume one,
        # so parameter counts in the results table are comparable and no arm
        # carries dead parameters that never receive gradient
        self.ctx = (SetContextEncoder(d_in, n_symbols, d_model, d_z=d_z)
                    if mode in ("omega", "film") else None)
        self.film = FiLM(d_model, d_z) if mode == "film" else None
        if mode == "prefix":
            self.pre_x = nn.Linear(d_in, d_model)
            self.pre_y = nn.Embedding(n_symbols, d_model)
        self.head = OmegaHead(d_model, n_out, d_z,
                              static=(mode != "omega"))

    def forward(self, x, cx=None, cy=None):
        """x (N, T, d_in); cx (N, K, d_in); cy (N, K) -> logits (N, T, n_out)"""
        h = self.inp(x)
        tokens = z = None
        if self.mode == "prefix":
            p = self.pre_x(cx) + self.pre_y(cy)          # (N, K, d)
            P = p.shape[1]
            h = self.trunk(torch.cat([p, h], dim=1))[:, P:]
        else:
            if self.ctx is not None:
                tokens, z = self.ctx(cx, cy)
            if self.film is not None:
                h = self.film(h, z)
            h = self.trunk(h)
        return self.head(self.norm(h), tokens, z)
