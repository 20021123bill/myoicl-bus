#!/usr/bin/env python3
"""v4.0 -> v4.1 in-place upgrade.

WHAT IT CHANGES AND WHY
  The context injection is  h = x + tanh(g) * o_proj(Attn(...)).  v4.0 put the
  identity-at-init on the SCALAR g, which makes d(loss)/d(everything inside the
  attention, and hence the whole context encoder) exactly proportional to
  tanh(g) = 0.  The only movable parameter is g itself, whose gradient is the
  inner product of dL/dh with a randomly initialized attention output -- noise.
  Deadlock: the gate cannot open, and until it opens nothing inside can learn.

  Measured 2026-08-18 on two independent runs (20k and 50k steps): gates ended
  at tanh(g) = -0.0001, -0.0014, -0.0035, -0.0004 -- four for four still shut --
  while FiLM in the SAME models, which zeroes its output MATRIX instead, had
  moved one to two orders of magnitude.

  v4.1 moves the zero to o_proj (a matrix) and starts the gate OPEN at g = 1.
  Still an exact identity at t=0, but now d(loss)/d(o_proj) != 0 so the branch
  learns from step 1.  Same pattern LoRA uses.  Gates are also exempted from
  weight decay: decaying a gate toward zero is decaying it toward "ignore
  context".

Idempotent: re-running is a no-op.
"""
import re
import sys
import pathlib

ROOT = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".")
PKG = ROOT / "myoicl"
changed, skipped, failed = [], [], []


def patch(relpath, subs):
    p = PKG / relpath
    if not p.exists():
        failed.append(f"{relpath}: MISSING")
        return
    s = orig = p.read_text()
    for sub in subs:
        old, new, tag = sub[0], sub[1], sub[2]
        guard = sub[3] if len(sub) > 3 else None
        # `guard` is for substitutions whose OLD text still occurs inside the
        # NEW text (e.g. inserting a helper above an existing def). Without it
        # the "already applied?" test is unreliable and re-running duplicates.
        if guard is not None:
            if guard in s:
                skipped.append(f"{relpath}:{tag}")
                continue
        elif new in s and old not in s:
            skipped.append(f"{relpath}:{tag}")
            continue
        n = s.count(old)
        if n != 1:
            failed.append(f"{relpath}:{tag}: anchor found {n} times, expected 1")
            return
        s = s.replace(old, new)
        changed.append(f"{relpath}:{tag}")
    if s != orig:
        p.write_text(s)


# ---------------------------------------------------------------- context.py
patch("context.py", [
    (
        """        dropout: float = 0.0,
        d_bneck: int | None = None,
    ) -> None:""",
        """        dropout: float = 0.0,
        d_bneck: int | None = None,
        gate_init: float = 1.0,
        zero_output: bool = True,
    ) -> None:""",
        "signature",
    ),
    (
        """        self.o_proj = nn.Linear(d_bneck, d_model)
        self.dropout = nn.Dropout(dropout)
        self.gate = nn.Parameter(torch.zeros(1))""",
        """        self.o_proj = nn.Linear(d_bneck, d_model)
        self.dropout = nn.Dropout(dropout)
        # Identity at init lives in the output MATRIX, not in the scalar gate.
        # With the zero on the scalar, d(loss)/d(anything inside the attention)
        # is exactly proportional to tanh(g)=0, so the context encoder receives
        # no gradient until the gate opens -- and the gate's own gradient is
        # dL/dh dotted with a random attention output, i.e. noise. Measured
        # 2026-08-18: four gates over two runs all still shut after 20k-50k
        # steps, while FiLM (which zeroes a matrix) had moved 1-2 orders of
        # magnitude. Zeroing o_proj keeps the exact identity at t=0 AND gives
        # o_proj a nonzero gradient immediately. This is the LoRA pattern.
        if zero_output:
            nn.init.zeros_(self.o_proj.weight)
            nn.init.zeros_(self.o_proj.bias)
        self.gate = nn.Parameter(torch.full((1,), float(gate_init)))
        # Read by the optimizer to build a no-weight-decay group.
        self.gate._no_weight_decay = True""",
        "zero-init-matrix",
    ),
])

# ------------------------------------------------------------------ model.py
patch("model.py", [
    (
        """        input_conditioning: bool = False,
    ) -> None:""",
        """        input_conditioning: bool = False,
        gate_init: float = 1.0,
    ) -> None:""",
        "signature",
    ),
    (
        """        input_conditioning=bool(m.get("input_conditioning", False)),
    )""",
        """        input_conditioning=bool(m.get("input_conditioning", False)),
        # 1.0 = post-2026-08-18 default (identity comes from zero-init o_proj,
        # not from a shut gate). Set 0.0 to reproduce the deadlock for the
        # ablation row.
        gate_init=float(m.get("gate_init", 1.0)),
    )""",
        "build_model",
    ),
])

# both cross-attention call sites (identical text, so handled separately)
mp = PKG / "model.py"
s = mp.read_text()
old_call = """            d_model, d_ctx, n_heads=cross_heads,
            ref_context_size=ref_context_size, d_bneck=d_bneck
        )"""
new_call = """            d_model, d_ctx, n_heads=cross_heads,
            ref_context_size=ref_context_size, d_bneck=d_bneck,
            gate_init=gate_init,
        )"""
if s.count(old_call) == 2:
    s = s.replace(old_call, new_call)
    mp.write_text(s)
    changed.append("model.py:cross-attn-callsites(2)")
elif s.count(new_call) == 2:
    skipped.append("model.py:cross-attn-callsites")
else:
    failed.append(f"model.py: cross-attn call sites found {s.count(old_call)}, expected 2")

# ----------------------------------------------------------- train_qwerty.py
OLD_OPT = """    base_lr = float(tcfg.get("lr", 1e-3))
    ctx_lr = float(tcfg.get("ctx_lr", base_lr))
    ctx_prefixes = ("ctx_encoder.", "film.", "cross_pre.", "cross_post.")
    ctx_params, bb_params = [], []
    for _n, _p in model.named_parameters():
        if not _p.requires_grad:
            continue
        (ctx_params if _n.startswith(ctx_prefixes) else bb_params).append(_p)
    groups = []
    if bb_params:
        groups.append({"params": bb_params, "lr": base_lr})
    if ctx_params:
        groups.append({"params": ctx_params, "lr": ctx_lr})
    print(f"[optim] backbone {sum(p.numel() for p in bb_params) / 1e6:.2f}M "
          f"@ lr {base_lr:.1e} | context "
          f"{sum(p.numel() for p in ctx_params) / 1e6:.2f}M @ lr {ctx_lr:.1e}")
    optimizer = torch.optim.AdamW(
        groups,
        lr=base_lr,
        weight_decay=float(tcfg.get("weight_decay", 0.0)),
        betas=tuple(tcfg.get("betas", [0.9, 0.98])),
    )"""

NEW_OPT = """    base_lr = float(tcfg.get("lr", 1e-3))
    ctx_lr = float(tcfg.get("ctx_lr", base_lr))
    ctx_prefixes = ("ctx_encoder.", "film.", "cross_pre.", "cross_post.")
    wd = float(tcfg.get("weight_decay", 0.0))
    buckets = {("bb", True): [], ("bb", False): [],
               ("ctx", True): [], ("ctx", False): []}
    for _n, _p in model.named_parameters():
        if not _p.requires_grad:
            continue
        which = "ctx" if _n.startswith(ctx_prefixes) else "bb"
        # Gates are decay-exempt: shrinking a gate toward zero is shrinking it
        # toward "ignore context", which is the failure we are escaping.
        decay = not getattr(_p, "_no_weight_decay", False)
        buckets[(which, decay)].append(_p)
    groups = []
    for (which, decay), ps in buckets.items():
        if ps:
            groups.append({"params": ps,
                           "lr": ctx_lr if which == "ctx" else base_lr,
                           "weight_decay": wd if decay else 0.0})
    _n_bb = sum(p.numel() for k, v in buckets.items() if k[0] == "bb" for p in v)
    _n_ctx = sum(p.numel() for k, v in buckets.items() if k[0] == "ctx" for p in v)
    _n_nodecay = sum(p.numel() for k, v in buckets.items() if not k[1] for p in v)
    print(f"[optim] backbone {_n_bb / 1e6:.2f}M @ lr {base_lr:.1e} | "
          f"context {_n_ctx / 1e6:.2f}M @ lr {ctx_lr:.1e} | "
          f"{_n_nodecay} params exempt from weight decay")
    optimizer = torch.optim.AdamW(
        groups,
        lr=base_lr,
        weight_decay=wd,
        betas=tuple(tcfg.get("betas", [0.9, 0.98])),
    )"""

patch("train_qwerty.py", [(OLD_OPT, NEW_OPT, "optimizer-nodecay-groups")])

# ----------------------------------------------------------- gate_report.py
patch("gate_report.py", [
    (
        '            flag = "OPEN " if abs(t) > 1e-3 else "CLOSED"',
        "            flag = _flag(abs(t) > 0.05, abs(t) > 5e-3)",
        "gate-threshold",
    ),
    (
        '            flag = "OPEN " if mx > 1e-4 else "CLOSED"',
        "            flag = _flag(mx > 1e-2, mx > 1e-4)",
        "matrix-threshold",
    ),
    (
        "def report(path: str) -> None:",
        '''def _flag(is_open: bool, is_ajar: bool) -> str:
    """Three states: "not exactly zero" is not the same as "open". A
    cross-attention residual scaled by 0.003 contributes nothing."""
    return "OPEN  " if is_open else ("AJAR  " if is_ajar else "CLOSED")


def report(path: str) -> None:''',
        "three-state-flag",
        "def _flag(",
    ),
])

# --------------------------------------------------------------- config: D2
fc = PKG / "configs" / "qwerty_forcectx.yaml"
if fc.exists():
    s = fc.read_text()
    if "gate_init" not in s:
        s = s.replace(
            "  ref_context_size: 32\n  dropout: 0.1",
            "  ref_context_size: 32\n  dropout: 0.1\n"
            "  # Identity-at-init now lives in the zero-initialized o_proj\n"
            "  # matrix, so the gate can start open and the context encoder\n"
            "  # receives gradient from step 1. Set 0.0 to reproduce the\n"
            "  # pre-2026-08-18 deadlock (ablation row).\n"
            "  gate_init: 1.0",
        )
        s = s.replace("runs/myoicl_forcectx", "runs/myoicl_d2_forcectx")
        fc.write_text(s)
        changed.append("configs/qwerty_forcectx.yaml:gate_init")
    else:
        skipped.append("configs/qwerty_forcectx.yaml")

    # ----------------------------------------------------------- config: D1
    d1 = PKG / "configs" / "qwerty_gatefix.yaml"
    t = fc.read_text()
    t = t.replace("DIAGNOSTIC ARM D2", "DIAGNOSTIC ARM D1")
    t = t.replace("can the architecture use context AT ALL?",
                  "was the shut gate the WHOLE problem?")
    t = t.replace("runs/myoicl_d2_forcectx", "runs/myoicl_d1_gatefix")
    t = t.replace("seed: 1503", "seed: 1504")
    t = t.replace("  mode_probs: [0.05, 0.15, 0.80]",
                  "  mode_probs: [0.10, 0.20, 0.70]")
    t = re.sub(r"  p_synth: 0\.85\n  synth_strength: \[0\.35, 0\.90\]",
               "  # D1 keeps the REAL difficulty: no synthetic crutch. Paired\n"
               "  # with D2 (p_synth 0.85) this isolates \"the gate was shut\"\n"
               "  # from \"real cross-user structure is too weak to open it\".\n"
               "  p_synth: 0.15\n  synth_strength: [0.15, 0.45]", t)
    if not d1.exists() or d1.read_text() != t:
        d1.write_text(t)
        changed.append("configs/qwerty_gatefix.yaml:created")
    else:
        skipped.append("configs/qwerty_gatefix.yaml")
else:
    failed.append("configs/qwerty_forcectx.yaml: MISSING")

# ------------------------------------------------------------------- report
print("=== v4.1 patch report ===")
for c in changed:
    print("  CHANGED ", c)
for c in skipped:
    print("  already ", c)
for c in failed:
    print("  FAILED  ", c)

import ast
ok = True
for f in ["context.py", "model.py", "train_qwerty.py", "gate_report.py"]:
    try:
        ast.parse((PKG / f).read_text())
        print(f"  AST OK   {f}")
    except Exception as e:
        ok = False
        print(f"  AST FAIL {f}: {e}")

import yaml
for f in ["qwerty_gatefix.yaml", "qwerty_forcectx.yaml"]:
    try:
        c = yaml.safe_load((PKG / "configs" / f).read_text())
        print(f"  YAML OK  {f} | p_synth={c['episodes']['p_synth']} "
              f"gate_init={c['model'].get('gate_init')} "
              f"lr={c['train']['lr']}/{c['train']['ctx_lr']} "
              f"out={c['out_dir'].split('/')[-1]}")
    except Exception as e:
        ok = False
        print(f"  YAML FAIL {f}: {e}")

sys.exit(0 if (ok and not failed) else 1)
