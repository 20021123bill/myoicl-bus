#!/usr/bin/env bash
# DIAGNOSTIC D1 -- was the shut gate the WHOLE problem?
# Gate fix on, real data difficulty (p_synth 0.15). 8000 steps, ~45 min, GPU2.
set -uo pipefail
cd /data2/chenyuxiang/code/myoicl
export PATH=/data2/chenyuxiang/conda_envs/qwerty/bin:$PATH
export CUDA_VISIBLE_DEVICES=2
python -m myoicl.train_qwerty --config myoicl/configs/qwerty_gatefix.yaml
