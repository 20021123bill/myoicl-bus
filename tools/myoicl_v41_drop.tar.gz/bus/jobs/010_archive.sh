#!/usr/bin/env bash
# Copy everything from last night's runs into bus/results/ so it travels
# through the repo. /data2/chenyuxiang/runs/ is gitignored and lives outside
# the repo, so nothing in it is visible otherwise.
set -uo pipefail
cd /data2/chenyuxiang/code/myoicl
export PATH=/data2/chenyuxiang/conda_envs/qwerty/bin:$PATH
A=bus/results/archive
mkdir -p "$A"

for f in /data2/chenyuxiang/runs/joint.log /data2/chenyuxiang/runs/scratch.log \
         /data2/chenyuxiang/runs/d1_gatefix.log /data2/chenyuxiang/runs/d2_forcectx.log; do
  [ -e "$f" ] && cp -f "$f" "$A/"
done
[ -e /data2/chenyuxiang/runs/myoicl_joint/log.csv   ] && cp -f /data2/chenyuxiang/runs/myoicl_joint/log.csv   "$A/joint_log.csv"
[ -e /data2/chenyuxiang/runs/myoicl_scratch/log.csv ] && cp -f /data2/chenyuxiang/runs/myoicl_scratch/log.csv "$A/scratch_log.csv"
cp -f /data2/chenyuxiang/runs/eval/*.json "$A/" 2>/dev/null
cp -f /tmp/e2_probe_user0.log "$A/" 2>/dev/null

echo "=== gate report (pre-v4.1 checkpoints) ==="
python -m myoicl.gate_report \
  /data2/chenyuxiang/runs/myoicl_joint/last.pt \
  /data2/chenyuxiang/runs/myoicl_scratch/best.pt 2>&1 | tee "$A/gate_report.txt"

echo "=== checkpoints on disk ==="
ls -la /data2/chenyuxiang/runs/myoicl_joint/*.pt /data2/chenyuxiang/runs/myoicl_scratch/*.pt 2>&1
echo "=== archived ==="
ls -la "$A"
