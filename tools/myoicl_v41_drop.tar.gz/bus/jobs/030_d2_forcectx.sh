#!/usr/bin/env bash
# DIAGNOSTIC D2 -- can the architecture use context AT ALL?
# Gate fix on + context made provably informative (p_synth 0.85).
# 8000 steps, ~45 min, GPU3.
set -uo pipefail
cd /data2/chenyuxiang/code/myoicl
export PATH=/data2/chenyuxiang/conda_envs/qwerty/bin:$PATH
export CUDA_VISIBLE_DEVICES=3
python -m myoicl.train_qwerty --config myoicl/configs/qwerty_forcectx.yaml
