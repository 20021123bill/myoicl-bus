# Copyright (c) 2026 MyoICL authors. MIT License.
"""Aggregate budget_curve.jsonl into the one table this project now depends on.

Per (user, budget) the learning rate is chosen by the subject's own VAL CER
and the corresponding TEST CER is reported -- never the best test cell, which
would be an oracle and would invent a ceiling that no deployable method could
reach.
"""
from __future__ import annotations

import argparse
import json
from collections import defaultdict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jsonl", required=True)
    ap.add_argument("--published-personalised", type=float, default=9.7,
                    help="fairemg Tiny personalised reference, the sanity "
                         "anchor for the full-data point")
    args = ap.parse_args()

    rows = []
    with open(args.jsonl) as f:
        for line in f:
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
    if not rows:
        raise SystemExit("no rows")

    cells = defaultdict(list)
    for r in rows:
        if r.get("test_cer") is None:
            continue
        cells[(r["user"], r["budget_min"])].append(r)

    dirty = {r["user"] for r in rows if not r.get("clean_val", True)}
    if dirty:
        print(f"[warn] LR selection not clean (no val sessions) for: "
              f"{sorted(dirty)} -- their rows are an OPTIMISTIC ceiling\n")

    picked = {}
    for k, rs in cells.items():
        best = min(rs, key=lambda r: (r.get("val_cer", float("inf")),
                                      r.get("lr", 0)))
        picked[k] = best

    budgets = sorted({b for _, b in picked}, key=lambda b: (b < 0, b))
    users = sorted({u for u, _ in picked})

    zs = {}
    for u in users:
        z = [r["zeroshot_test"] for (uu, _), r in picked.items() if uu == u]
        zs[u] = sum(z) / len(z) if z else float("nan")

    print(f"{'budget':>9} {'n':>3} {'test CER':>9} {'vs 0-shot':>10} "
          f"{'chosen lr (mode)':>18}")
    print("-" * 54)
    summary = {}
    for b in budgets:
        rs = [picked[(u, b)] for u in users if (u, b) in picked]
        if not rs:
            continue
        m = sum(r["test_cer"] for r in rs) / len(rs)
        z = sum(r["zeroshot_test"] for r in rs) / len(rs)
        lrs = defaultdict(int)
        for r in rs:
            lrs[r.get("lr", 0)] += 1
        mode_lr = max(lrs.items(), key=lambda kv: kv[1])[0]
        label = "full" if b < 0 else ("0 (zero-shot)" if b == 0
                                      else f"{b:g} min")
        print(f"{label:>9} {len(rs):>3} {m:>9.2f} {z - m:>+10.2f} "
              f"{mode_lr:>18.1e}")
        summary[b] = m

    print()
    if -1 in summary:
        full = summary[-1]
        ref = args.published_personalised
        ok = abs(full - ref) < 6.0
        verdict = ("CONSISTENT -- the pipeline is trustworthy" if ok else
                   "INCONSISTENT -- fix the finetuning before reading "
                   "the curve")
        print(f"[anchor] full-data finetuning {full:.2f} vs published "
              f"personalised {ref:.1f}: {verdict}")
    if 3 in summary and 0 in summary:
        g = summary[0] - summary[3]
        print(f"[verdict] at the project's stated 3-minute budget the STRONGEST"
              f" possible adapter gains {g:+.2f} CER.")
        if g < 3.0:
            print("          -> the 3-minute premise is false. No zero-backprop"
                  "\n             method can beat this; the budget or the claim"
                  " must change.")
        else:
            print(f"          -> real headroom exists at 3 minutes. Any "
                  f"in-context\n             method must be judged against "
                  f"{summary[3]:.1f} CER, not against zero.")


if __name__ == "__main__":
    main()
