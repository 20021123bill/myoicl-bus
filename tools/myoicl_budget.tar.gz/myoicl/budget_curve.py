# Copyright (c) 2026 MyoICL authors. MIT License.
"""THE measurement that should have come first: how much can ANY method gain
from X minutes of a new subject's own labelled data?

Gradient finetuning is the strongest possible adapter -- it may rewrite every
weight, it sees the labels, it may train to convergence. No zero-backprop,
one-forward-pass method can beat it at the same data budget. So the curve
"CER vs minutes of the subject's own labelled data", produced by finetuning,
is the CEILING against which every in-context result must be read.

This project spent two weeks building an in-context adapter without ever
measuring that ceiling. If the curve is flat at 3 minutes, then gain = 0 was
the correct answer all along and no architecture could have changed it; if it
drops steeply, we have a target number and the failure is ours to fix.

DISCIPLINE, because a sloppy version of this measurement is worse than none:
  * learning rate is chosen on the subject's own VAL sessions and reported on
    their TEST sessions -- picking on test would manufacture a ceiling that
    does not exist, not picking at all would understate it;
  * the budget is counted in windows of known duration, drawn with a fixed
    seed, and the realised minutes are recorded in the output row;
  * the FULL-data point is the sanity anchor: the published personalised Tiny
    number is ~9.7-11.4 CER, so if our full-data finetuning lands near that,
    the whole pipeline is trustworthy; if it lands at 40, the finetuning is
    broken and THAT is the finding, before any curve is interpreted;
  * one (user, budget, lr) cell per process invocation, appended to a JSONL
    and skipped if already present -- jobs on this server have been dying to
    an external reaper, and a 120-cell sweep must survive losing any cell.

Usage (one cell):
    python -m myoicl.budget_curve --trunk <ckpt> --user user0 \
        --budget-min 3 --lr 1e-4 --out /path/curve.jsonl
    # --budget-min 0  -> zero-shot only (no finetuning)
    # --budget-min -1 -> all available calibration data (the anchor)
"""
from __future__ import annotations

import argparse
import json
import math
import os
import time

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader


def _eval_cer(model, samples, cs, device, bf16=True, batch_size=4):
    from emg2qwerty.data import LabelData

    from .episodes import windowed_collate
    from .metrics import CERAccumulator, greedy_ctc_decode

    if not samples:
        return float("nan")
    dl = DataLoader(samples, batch_size=batch_size, shuffle=False,
                    collate_fn=windowed_collate)
    acc = CERAccumulator()
    was_training = model.training
    model.eval()
    with torch.no_grad():
        for b in dl:
            raw = b["inputs"].to(device).permute(1, 2, 3, 0).flatten(1, 2)
            with torch.autocast(device_type=device.type,
                                dtype=torch.bfloat16, enabled=bf16):
                em = model(raw)
            lens = model.output_length(b["input_lengths"].to(device))
            preds = greedy_ctc_decode(em.float(), lens.cpu(),
                                      blank=cs.null_class)
            tg, tl = b["targets"].numpy(), b["target_lengths"].numpy()
            for n, p in enumerate(preds):
                acc.update(LabelData.from_labels(p).text,
                           LabelData.from_labels(tg[: tl[n], n]).text)
    if was_training:
        model.train()
    return acc.cer


def _fixed_windows(pairs, window_length, seed, cap=512, max_sessions=24):
    """Deterministic evaluation window list (matches train_trunk's monitor)."""
    from .episodes import build_windowed_dataset

    if not pairs:
        return None
    sub = pairs[:max_sessions]
    ds = build_windowed_dataset(sub, train=False,
                                window_length=window_length,
                                padding=(1800, 200), raw=True)
    if len(ds) == 0:
        return None
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(ds))[:cap]
    return [ds[int(i)] for i in idx]


def _done_cells(path):
    seen = set()
    if os.path.exists(path):
        with open(path) as f:
            for line in f:
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                seen.add((r.get("user"), r.get("budget_min"), r.get("lr")))
    return seen


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--trunk", required=True)
    ap.add_argument("--user", required=True, help="user0 .. user7")
    ap.add_argument("--budget-min", type=float, required=True,
                    help="minutes of the subject's own labelled data; "
                         "0 = zero-shot only, -1 = all available")
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--window-length", type=int, default=8000)
    ap.add_argument("--weight-decay", type=float, default=0.05)
    ap.add_argument("--grad-clip", type=float, default=0.1)
    ap.add_argument("--max-steps", type=int, default=1200)
    ap.add_argument("--eval-every", type=int, default=60)
    ap.add_argument("--patience", type=int, default=6,
                    help="evals without val improvement before stopping")
    ap.add_argument("--warmup-ratio", type=float, default=0.1)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    key = (args.user, args.budget_min, args.lr if args.budget_min else 0.0)
    if key in _done_cells(args.out):
        print(f"[skip] {key} already in {args.out}")
        return

    torch.manual_seed(args.seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    from emg2qwerty.charset import charset as charset_fn

    from .episodes import build_windowed_dataset, windowed_collate
    from .qwerty_data import load_user_sessions
    from .trunk_tf import build_trunk

    cs = charset_fn()
    s = load_user_sessions(args.repo_root, args.user, args.data_root)
    n_tr, n_va, n_te = len(s["train"]), len(s["val"]), len(s["test"])
    print(f"[user] {args.user}: {n_tr} calibration / {n_va} val / "
          f"{n_te} test sessions")
    if n_te == 0:
        raise SystemExit(f"[FATAL] {args.user} has no test sessions")

    ck = torch.load(args.trunk, map_location="cpu")
    model = build_trunk({"model": {"tf_size": ck["args"]["size"],
                                   "conv_strides": ck["args"].get(
                                       "conv_strides", [5, 2, 2]),
                                   "conv_kernels": ck["args"].get(
                                       "conv_kernels", [11, 3, 3])}},
                        num_classes=cs.num_classes).to(dev)
    model.load_state_dict(ck["model"])
    print(f"[trunk] {args.trunk} step {ck.get('step')} "
          f"fold {ck.get('args', {}).get('fold')}")

    te_win = _fixed_windows(s["test"], 10000, seed=1, cap=512)
    va_win = _fixed_windows(s["val"] or s["test"], 10000, seed=2, cap=256)
    print(f"[eval] {len(te_win or [])} test windows, "
          f"{len(va_win or [])} val windows"
          + ("  (NO val sessions: val falls back to test -- this cell's LR "
             "selection is NOT clean, flagged in the row)" if not s["val"]
             else ""))

    t0 = time.time()
    zs_test = _eval_cer(model, te_win, cs, dev)
    zs_val = _eval_cer(model, va_win, cs, dev)
    print(f"[zero-shot] test {zs_test:.2f} | val {zs_val:.2f} "
          f"({time.time() - t0:.0f}s)")

    row = {"user": args.user, "budget_min": args.budget_min,
           "lr": args.lr if args.budget_min else 0.0,
           "zeroshot_test": zs_test, "zeroshot_val": zs_val,
           "clean_val": bool(s["val"]), "trunk": args.trunk,
           "trunk_step": ck.get("step")}

    if args.budget_min == 0:
        row.update({"test_cer": zs_test, "val_cer": zs_val,
                    "n_windows": 0, "realised_min": 0.0, "steps": 0})
    else:
        ds = build_windowed_dataset(s["train"], train=True,
                                    window_length=args.window_length,
                                    padding=(1800, 200), raw=True)
        win_s = args.window_length / 2000.0
        if args.budget_min < 0:
            n_win = len(ds)
        else:
            n_win = int(round(args.budget_min * 60.0 / win_s))
        n_win = max(1, min(n_win, len(ds)))
        rng = np.random.default_rng(args.seed + 17)
        pick = rng.permutation(len(ds))[:n_win]
        sub = [ds[int(i)] for i in pick]
        realised = n_win * win_s / 60.0
        print(f"[budget] {args.budget_min} min requested -> {n_win} windows "
              f"of {win_s:.1f}s = {realised:.2f} min realised "
              f"(pool {len(ds)} windows)")
        row.update({"n_windows": n_win, "realised_min": realised,
                    "pool_windows": len(ds)})

        bs = min(args.batch, n_win)
        dl = DataLoader(sub, batch_size=bs, shuffle=True,
                        drop_last=len(sub) > bs, num_workers=2,
                        collate_fn=windowed_collate, persistent_workers=True)

        decay, no_decay = [], []
        for n, p in model.named_parameters():
            (no_decay if p.ndim <= 1 or "mask_emb" in n else decay).append(p)
        opt = torch.optim.AdamW(
            [{"params": decay, "weight_decay": args.weight_decay},
             {"params": no_decay, "weight_decay": 0.0}],
            lr=args.lr, betas=(0.9, 0.98))
        warm = max(1, int(args.warmup_ratio * args.max_steps))

        def lr_at(st):
            if st < warm:
                return st / warm
            t = (st - warm) / max(1, args.max_steps - warm)
            return 0.5 * (1 + math.cos(math.pi * min(t, 1.0)))

        sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_at)

        best_val = zs_val
        best_state = {k: v.detach().clone()
                      for k, v in model.state_dict().items()}
        best_step, bad = 0, 0
        step, stop = 0, False
        model.train()
        while not stop:
            for b in dl:
                raw = b["inputs"].to(dev).permute(1, 2, 3, 0).flatten(1, 2)
                with torch.autocast(device_type=dev.type,
                                    dtype=torch.bfloat16, enabled=True):
                    em = model(raw)
                in_len = model.output_length(b["input_lengths"].to(dev))
                loss = nn.functional.ctc_loss(
                    em.float(), b["targets"].transpose(0, 1).to(dev), in_len,
                    b["target_lengths"].to(dev), blank=cs.null_class,
                    zero_infinity=True)
                opt.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
                opt.step(); sched.step()
                step += 1
                if step % args.eval_every == 0:
                    v = _eval_cer(model, va_win, cs, dev)
                    tag = ""
                    if v < best_val - 1e-6:
                        best_val, best_step, bad = v, step, 0
                        best_state = {k: p.detach().clone()
                                      for k, p in model.state_dict().items()}
                        tag = "  <- best"
                    else:
                        bad += 1
                    print(f"  step {step:5d} | loss {float(loss):.3f} | "
                          f"val {v:.2f} (best {best_val:.2f} @ {best_step})"
                          f"{tag}", flush=True)
                    if bad >= args.patience:
                        print(f"  [early stop] {bad} evals without "
                              f"improvement"); stop = True; break
                if step >= args.max_steps:
                    stop = True; break

        # EARLY STOPPING IS PART OF THE ADAPTER, not a courtesy: with 45
        # windows the model overfits in a few hundred steps, and a ceiling
        # measured at the overfitted point would understate what the budget
        # actually affords. best_state is the val-selected checkpoint.
        model.load_state_dict(best_state)
        te = _eval_cer(model, te_win, cs, dev)
        row.update({"test_cer": te, "val_cer": best_val,
                    "steps": step, "best_step": best_step,
                    "gain_vs_zeroshot": zs_test - te})
        print(f"[result] {args.user} budget {args.budget_min} lr {args.lr}: "
              f"test {te:.2f} (zero-shot {zs_test:.2f}, "
              f"gain {zs_test - te:+.2f})")

    row["wall_s"] = round(time.time() - t0, 1)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "a") as f:
        f.write(json.dumps(row) + "\n")
    print(f"[appended] {args.out}")


if __name__ == "__main__":
    main()
