# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part B main line: LM beam decode -> confident segments -> online
self-training of the ENCODER -> report how much of the generic->personalised
gap zero-label personalisation eats.

Three things earlier runs got wrong, all of them mine:

1. THE SPEC SAYS UPDATE THE ENCODER. "在线自训练更新编码器(或只更新归一化
   统计量/轻量 adapter ...)" -- the encoder is the main option and the
   normalisation/adapter route is the parenthetical fallback. Earlier runs did
   only the fallback, and the last one narrowed it to 64 scalars, where label
   content cannot be represented at all.

2. LM BEAM SEARCH IS REQUIRED, NOT OPTIONAL. flashlight-text is absent and
   torchaudio's decoder depends on it, so the beam search is implemented here.
   The earlier attempt scored 82.57 against greedy 69.43 because of a UNIT
   BUG: kenlm returns log10 while the acoustic scores are natural log, and
   adding them directly inflates the LM weight by ln(10) = 2.303. It also
   omitted the insertion bonus, without which the LM's preference for short
   strings deletes characters. Both are fixed here, with the official config's
   values (lm_weight 2.0, insertion_bonus 2.0).

3. THE HEADLINE METRIC IS GAP EATEN. generic 55.39, personalised-with-labels
   11.28, so the gap is 44.11 CER. What matters is the fraction of that gap
   closed with zero labels, not an isolated delta.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
from collections import defaultdict
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn

LN10 = math.log(10.0)
GENERIC_REF = 55.39
PERSONALISED_REF = 11.28


class CharLM:
    """kenlm character LM. Boundary token is kenlm's own </s>, per the
    official decoder.py (EOW = "</s>"); verified OOV 0.0%, real text above
    shuffled, correct spelling above misspelling."""

    def __init__(self, path):
        import kenlm

        self.m = kenlm.Model(path)
        self._c = {"": 0.0}

    @staticmethod
    def _tok(t):
        return " ".join("</s>" if ch == " " else ch for ch in t)

    def _full(self, text):
        if text in self._c:
            return self._c[text]
        v = self.m.score(self._tok(text), bos=True, eos=False)
        self._c[text] = v
        return v

    def delta_nat(self, text):
        """Natural-log increment for the last character of `text`."""
        if not text:
            return 0.0
        return (self._full(text) - self._full(text[:-1])) * LN10


def beam_decode(em, blank, id2char, lm, lm_weight=2.0, insertion=2.0,
                beam=25, prune=-9.0):
    """CTC prefix beam search with kenlm shallow fusion, all in natural log.

    em: (T, K) log-probs. Returns the decoded string.
    """
    T, K = em.shape
    lp = em.detach().float().cpu().numpy()
    # prefix -> [p_blank, p_nonblank, lm_score(nat), text]
    beams = {(): [0.0, -np.inf, 0.0, ""]}

    def lse(a, b):
        if a == -np.inf:
            return b
        if b == -np.inf:
            return a
        m = max(a, b)
        return m + math.log(math.exp(a - m) + math.exp(b - m))

    for t in range(T):
        row = lp[t]
        cand = np.where(row > prune)[0]
        if blank not in cand:
            cand = np.append(cand, blank)
        nxt = {}

        def get(key, text, lms):
            if key not in nxt:
                nxt[key] = [-np.inf, -np.inf, lms, text]
            return nxt[key]

        for pref, (pb, pnb, lms, text) in beams.items():
            tot = lse(pb, pnb)
            for k in cand:
                p = float(row[k])
                if k == blank:
                    e = get(pref, text, lms)
                    e[0] = lse(e[0], tot + p)
                    continue
                ch = id2char.get(int(k), "")
                last = pref[-1] if pref else None
                if k == last:
                    e = get(pref, text, lms)
                    e[1] = lse(e[1], pnb + p)          # extend same char
                    npref = pref + (int(k),)
                    ntext = text + ch
                    e2 = get(npref, ntext,
                             lms + lm_weight * lm.delta_nat(ntext) + insertion)
                    e2[1] = lse(e2[1], pb + p)         # new char after blank
                else:
                    npref = pref + (int(k),)
                    ntext = text + ch
                    e2 = get(npref, ntext,
                             lms + lm_weight * lm.delta_nat(ntext) + insertion)
                    e2[1] = lse(e2[1], tot + p)
        scored = sorted(nxt.items(),
                        key=lambda kv: -(lse(kv[1][0], kv[1][1]) + kv[1][2]))
        beams = {k: v for k, v in scored[:beam]}
    best = max(beams.items(), key=lambda kv: lse(kv[1][0], kv[1][1]) + kv[1][2])
    return best[1][3]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--user", required=True)
    ap.add_argument("--cal-windows", type=int, default=256)
    ap.add_argument("--beam", type=int, default=25)
    ap.add_argument("--lm-weight", type=float, default=2.0)
    ap.add_argument("--insertion", type=float, default=2.0)
    ap.add_argument("--scope", default="encoder",
                    choices=["encoder", "norm", "all"])
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--steps", type=int, default=250)
    ap.add_argument("--lr", type=float, default=1e-5)
    ap.add_argument("--ema", type=float, default=0.995)
    ap.add_argument("--quantile", type=float, default=0.5,
                    help="confidence quantile among beam/greedy-consistent "
                         "windows")
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import yaml
    from emg2qwerty.charset import charset as charset_fn
    from emg2qwerty.data import LabelData
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate
    from .eval_qwerty import eval_user
    from .metrics import CERAccumulator, greedy_ctc_decode
    from .model import build_model
    from .pretrained import load_official_backbone
    from .tta_floor import unlabelled_windows

    cfg = yaml.safe_load(open(a.config))
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()
    torch.manual_seed(a.seed); np.random.seed(a.seed)

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, cfg.get("init_backbone_from"))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)

    id2char = {}
    for i in range(cs.num_classes - 1):
        try:
            t = LabelData.from_labels([i]).text
            if len(t) == 1:
                id2char[i] = t
        except Exception:
            pass
    lm = CharLM(f"{a.repo_root}/models/lm/wikitext-103-6gram-charlm.bin")

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    base = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A", ea,
                     dev).cer
    print(f"[{a.user}] unadapted {base:.2f} | gap to personalised "
          f"{base - PERSONALISED_REF:.2f}", flush=True)

    cal = unlabelled_windows(a.repo_root, a.data_root, a.user, a.cal_windows,
                             ea.window_length, ea.padding, a.seed)
    if not cal:
        raise SystemExit("[FATAL] no windows")

    # trainable set
    params = []
    if a.scope == "encoder":
        for n_, p in model.named_parameters():
            if n_.startswith(("tds.", "frontend.1.", "classifier.")):
                p.requires_grad_(True); params.append(p)
    elif a.scope == "all":
        for p in model.parameters():
            p.requires_grad_(True); params.append(p)
    else:
        for n_, m in model.named_modules():
            if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.LayerNorm)):
                for p in (m.weight, m.bias):
                    if p is not None:
                        p.requires_grad_(True); params.append(p)
    print(f"[{a.user}] scope={a.scope}: "
          f"{sum(p.numel() for p in params)} trainable scalars", flush=True)

    teacher = copy.deepcopy(model)
    for p in teacher.parameters():
        p.requires_grad_(False)

    def decode_pool(net):
        """beam + greedy on the pool; returns records."""
        recs = []
        dl = DataLoader(cal, batch_size=4, shuffle=False,
                        collate_fn=windowed_collate)
        net.eval()
        with torch.no_grad():
            for b in dl:
                em = net(b["inputs"].to(dev)).float()
                lens = torch.full((em.shape[1],), em.shape[0],
                                  dtype=torch.long)
                g = greedy_ctc_decode(em, lens, blank=cs.null_class)
                p = em.exp(); top = p.max(-1)
                tg, tl = b["targets"].numpy(), b["target_lengths"].numpy()
                for n in range(em.shape[1]):
                    gt = LabelData.from_labels(g[n]).text
                    bt = beam_decode(em[:, n], cs.null_class, id2char, lm,
                                     a.lm_weight, a.insertion, a.beam)
                    nb = top.indices[:, n] != cs.null_class
                    c = (float(top.values[:, n][nb].mean())
                         if int(nb.sum()) else 0.0)
                    ppl = (-lm._full(bt) / max(len(bt), 1)) if bt else 9e9
                    recs.append({
                        "greedy": gt, "beam": bt, "conf": c, "ppl": ppl,
                        "true": LabelData.from_labels(tg[: tl[n], n]).text,
                        "ids": [i for i in
                                (cs.key_to_label(ch) if hasattr(cs, "key_to_label")
                                 else None for ch in bt) if i is not None],
                    })
        return recs

    def ids_of(text):
        out = []
        for ch in text:
            for i, c in id2char.items():
                if c == ch:
                    out.append(i); break
        return out

    hist = [{"round": 0, "cer": base}]
    for r in range(1, a.rounds + 1):
        recs = decode_pool(teacher)
        cg = CERAccumulator(); cb = CERAccumulator()
        for x in recs:
            cg.update(x["greedy"], x["true"]); cb.update(x["beam"], x["true"])
        # the plan's filter: beam/greedy consistent + high confidence + low ppl
        cons = [i for i, x in enumerate(recs)
                if x["beam"] and x["beam"] == x["greedy"]]
        pool = cons if len(cons) >= 8 else list(range(len(recs)))
        cq = np.quantile([recs[i]["conf"] for i in pool], a.quantile)
        pq = np.quantile([recs[i]["ppl"] for i in pool], 1 - a.quantile)
        keep = [i for i in pool
                if recs[i]["conf"] >= cq and recs[i]["ppl"] <= pq
                and len(recs[i]["beam"]) > 2]
        pc = CERAccumulator()
        for i in keep:
            pc.update(recs[i]["beam"], recs[i]["true"])
        print(f"[{a.user}] r{r} decode: greedy {cg.cer:.2f} | beam "
              f"{cb.cer:.2f} ({'beam better' if cb.cer < cg.cer else 'BEAM WORSE'})"
              f" | consistent {len(cons)}/{len(recs)} | kept {len(keep)} at "
              f"pseudo-CER {pc.cer:.2f}", flush=True)
        if len(keep) < 4:
            print(f"[{a.user}] r{r}: too few kept"); break

        opt = torch.optim.AdamW(params, lr=a.lr, weight_decay=0.0)
        model.train()
        done = 0; losses = []
        while done < a.steps:
            for s in range(0, len(keep), 2):
                ch = keep[s:s + 2]
                b = windowed_collate([cal[i] for i in ch])
                em = model(b["inputs"].to(dev)).float()
                tg, tl = [], []
                for i in ch:
                    t = ids_of(recs[i]["beam"])
                    tg.append(t); tl.append(len(t))
                if not tg or min(tl) == 0:
                    continue
                T = torch.zeros(len(tg), max(tl), dtype=torch.long)
                for j, t in enumerate(tg):
                    T[j, : len(t)] = torch.tensor(t, dtype=torch.long)
                n = min(em.shape[1], len(tg))
                loss = nn.functional.ctc_loss(
                    em[:, :n], T[:n].to(dev),
                    torch.full((n,), em.shape[0], device=dev),
                    torch.tensor(tl[:n], device=dev),
                    blank=cs.null_class, zero_infinity=True)
                if not torch.isfinite(loss):
                    continue
                opt.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(params, 1.0)
                opt.step()
                with torch.no_grad():
                    for pt, psd in zip(teacher.parameters(),
                                       model.parameters()):
                        pt.mul_(a.ema).add_(psd.detach(), alpha=1 - a.ema)
                losses.append(float(loss)); done += 1
                if done >= a.steps:
                    break
        model.eval()
        cer = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A", ea,
                        dev).cer
        eaten = (base - cer) / max(base - PERSONALISED_REF, 1e-6) * 100
        hist.append({"round": r, "cer": cer, "kept": len(keep),
                     "pseudo_cer": pc.cer, "beam": cb.cer, "greedy": cg.cer,
                     "loss": float(np.mean(losses)) if losses else None,
                     "gap_eaten_pct": eaten})
        print(f"[{a.user}] r{r} RESULT: {base:.2f} -> {cer:.2f} "
              f"({base - cer:+.2f}) = {eaten:.1f}% of the gap, ZERO labels",
              flush=True)
        json.dump({"args": vars(a), "base": base, "hist": hist},
                  open(a.out, "w"), indent=1)

    fin = hist[-1]["cer"]
    eaten = (base - fin) / max(base - PERSONALISED_REF, 1e-6) * 100
    print(f"\n[FINAL] {a.user}: {base:.2f} -> {fin:.2f} "
          f"({base - fin:+.2f}) | gap eaten {eaten:.1f}%", flush=True)
    json.dump({"args": vars(a), "base": base, "hist": hist, "final": fin,
               "gain": base - fin, "gap_eaten_pct": eaten},
              open(a.out, "w"), indent=1)


if __name__ == "__main__":
    main()
