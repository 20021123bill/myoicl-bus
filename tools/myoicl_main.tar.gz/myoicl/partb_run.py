# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part B, as the plan actually specifies it. Run it, report CER.

WHAT WAS MISSING UNTIL NOW. The plan's section 2.3 step 3 reads:
"student 只更新 LayerNorm/BatchNorm 仿射参数 + 轻量 adapter". Every run so far
updated the normalisation affines and NO adapter -- and the final control even
narrowed that to the input BatchNorm alone, 64 scalars. Sixty-four parameters
can only rescale the input, which is why shuffled pseudo-labels tied confident
ones: there was no capacity for label content to live in. That was not a
finding about the method; it was a missing component.

This module implements the specified pipeline end to end:

  stage 0  curriculum step one -- recalibrate normalisation STATISTICS on the
           user's unlabelled data, no gradients (the plan's BTTA-DG-style
           gradient-free warm start)
  stage 1  EMA teacher decodes the unlabelled pool -> pseudo-labels
           filter: per-window non-blank confidence above a data-driven
           quantile (beam/LM agreement is unavailable on this machine --
           flashlight-text is absent and torchaudio's decoder needs it too)
  stage 2  student trains with CTC on the filtered pseudo-labels; trainable =
           norm affines + a zero-initialised bottleneck adapter placed
           immediately before the CTC head, so step 0 is exactly the published
           model; teacher <- EMA(student)
  repeat stages 1-2 for several rounds, regenerating pseudo-labels each time

Reported: CER before, after each round, and at the end. One number per user.
A `shuffled` arm is available (--mode shuffled) to confirm the adapter is
learning label content rather than just moving; it costs one extra run and is
the only check kept, because without it a positive number cannot be trusted.
"""
from __future__ import annotations

import argparse
import copy
import json
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


class Adapter(nn.Module):
    """Zero-initialised residual bottleneck. Identity at step 0 by
    construction, so the run starts from exactly the published model and any
    change is attributable to this module plus the norm affines."""

    def __init__(self, d_model: int, bottleneck: int = 64):
        super().__init__()
        self.norm = nn.LayerNorm(d_model)
        self.down = nn.Linear(d_model, bottleneck)
        self.up = nn.Linear(bottleneck, d_model)
        nn.init.zeros_(self.up.weight)
        nn.init.zeros_(self.up.bias)

    def forward(self, x):
        return x + self.up(nn.functional.gelu(self.down(self.norm(x))))


def attach_adapter(model, bottleneck=64):
    """Insert the adapter directly before the CTC head.

    model.classifier is nn.Linear(d_model, num_classes); wrapping it keeps the
    published architecture untouched and needs no surgery inside the encoder.
    """
    d = model.classifier.in_features
    ad = Adapter(d, bottleneck)
    model.classifier = nn.Sequential(ad, model.classifier)
    return ad


def recalibrate_norm_stats(model, samples, dev, batch_size=4):
    """Curriculum stage 0: normalisation statistics only, no gradients."""
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate

    bns = [m for m in model.modules()
           if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d))]
    if not bns:
        return 0
    mom = [m.momentum for m in bns]
    for m in bns:
        m.reset_running_stats(); m.momentum = None; m.train()
    dl = DataLoader(samples, batch_size=batch_size, shuffle=False,
                    collate_fn=windowed_collate)
    with torch.no_grad():
        for b in dl:
            model(b["inputs"].to(dev))
    for m, mm in zip(bns, mom):
        m.momentum = mm; m.eval()
    return len(bns)


def make_pseudo(teacher, samples, cs, dev, q, batch_size=4):
    """EMA teacher decodes the pool; keep windows above the q-quantile of
    non-blank confidence. Returns (keep_idx, ids_per_window, pseudo_cer)."""
    from emg2qwerty.data import LabelData
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate
    from .metrics import CERAccumulator, greedy_ctc_decode

    dl = DataLoader(samples, batch_size=batch_size, shuffle=False,
                    collate_fn=windowed_collate)
    ids, conf, truth, pred = [], [], [], []
    teacher.eval()
    with torch.no_grad():
        for b in dl:
            em = teacher(b["inputs"].to(dev)).float()
            lens = torch.full((em.shape[1],), em.shape[0], dtype=torch.long)
            g = greedy_ctc_decode(em, lens, blank=cs.null_class)
            p = em.exp(); top = p.max(-1)
            tg, tl = b["targets"].numpy(), b["target_lengths"].numpy()
            for n in range(em.shape[1]):
                nb = top.indices[:, n] != cs.null_class
                c = float(top.values[:, n][nb].mean()) if int(nb.sum()) else 0.
                ids.append(list(map(int, g[n]))); conf.append(c)
                pred.append(LabelData.from_labels(g[n]).text)
                truth.append(LabelData.from_labels(tg[: tl[n], n]).text)
    thr = float(np.quantile(conf, q))
    keep = [i for i, c in enumerate(conf) if c >= thr and len(ids[i]) > 0]
    acc = CERAccumulator()
    for i in keep:
        acc.update(pred[i], truth[i])
    return keep, ids, (acc.cer if keep else float("nan"))


def train_round(model, teacher, samples, keep, ids, cs, dev, steps, lr, ema,
                params, shuffle_labels=False, seed=0, batch_size=2):
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate

    rng = np.random.default_rng(seed)
    if shuffle_labels:
        pool = [ids[i] for i in keep]
        order = rng.permutation(len(pool))
        ids = dict(ids) if isinstance(ids, dict) else list(ids)
        ids = list(ids)
        for j, i in enumerate(keep):
            ids[i] = pool[int(order[j])]
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=0.0)
    model.train()
    done, losses = 0, []
    while done < steps:
        for s in range(0, len(keep), batch_size):
            chunk = keep[s:s + batch_size]
            b = windowed_collate([samples[i] for i in chunk])
            em = model(b["inputs"].to(dev)).float()
            tg, tl = [], []
            for i in chunk:
                t = [c for c in ids[i] if c != cs.null_class]
                tg.append(t); tl.append(len(t))
            if not tg or min(tl) == 0:
                continue
            T = torch.zeros(len(tg), max(tl), dtype=torch.long)
            for r, t in enumerate(tg):
                T[r, : len(t)] = torch.tensor(t, dtype=torch.long)
            n = min(em.shape[1], len(tg))
            loss = nn.functional.ctc_loss(
                em[:, :n], T[:n].to(dev),
                torch.full((n,), em.shape[0], device=dev),
                torch.tensor(tl[:n], device=dev),
                blank=cs.null_class, zero_infinity=True)
            if not torch.isfinite(loss):
                continue
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            with torch.no_grad():
                for pt, psd in zip(teacher.parameters(), model.parameters()):
                    pt.mul_(ema).add_(psd.detach(), alpha=1 - ema)
            losses.append(float(loss)); done += 1
            if done >= steps:
                break
    model.eval()
    return done, (float(np.mean(losses)) if losses else float("nan"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--user", required=True)
    ap.add_argument("--cal-windows", type=int, default=384)
    ap.add_argument("--quantile", type=float, default=0.75)
    ap.add_argument("--bottleneck", type=int, default=64)
    ap.add_argument("--rounds", type=int, default=3)
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--ema", type=float, default=0.99)
    ap.add_argument("--mode", default="conf", choices=["conf", "shuffled"])
    ap.add_argument("--no-stage0", action="store_true")
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import yaml
    from emg2qwerty.charset import charset as charset_fn

    from .eval_qwerty import eval_user
    from .model import build_model
    from .pretrained import load_official_backbone
    from .tta_floor import unlabelled_windows

    cfg = yaml.safe_load(open(a.config))
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()
    torch.manual_seed(a.seed); np.random.seed(a.seed)

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, cfg.get("init_backbone_from"))
    for p in model.parameters():
        p.requires_grad_(False)
    ad = attach_adapter(model, a.bottleneck).to(dev)
    model.eval()

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    base = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A", ea,
                     dev).cer
    n_ad = sum(p.numel() for p in ad.parameters())
    print(f"[{a.user}] adapter {n_ad} params (zero-init => identity); "
          f"unadapted CER {base:.2f}", flush=True)

    cal = unlabelled_windows(a.repo_root, a.data_root, a.user, a.cal_windows,
                             ea.window_length, ea.padding, a.seed)
    if not cal:
        raise SystemExit("[FATAL] no windows")

    if not a.no_stage0:
        n = recalibrate_norm_stats(model, cal, dev)
        c0 = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A", ea,
                       dev).cer
        print(f"[{a.user}] stage0 norm-stat recalibration ({n} BN layers, "
              f"no gradients): {base:.2f} -> {c0:.2f} "
              f"({base - c0:+.2f})", flush=True)
    else:
        c0 = base

    params = list(ad.parameters())
    for name, m in model.named_modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.LayerNorm,
                          nn.GroupNorm)) and "classifier.0" not in name:
            for p in (m.weight, m.bias):
                if p is not None:
                    p.requires_grad_(True); params.append(p)
    for p in ad.parameters():
        p.requires_grad_(True)
    print(f"[{a.user}] trainable: {sum(p.numel() for p in params)} scalars "
          f"(adapter {n_ad} + norm affines)", flush=True)

    teacher = copy.deepcopy(model)
    for p in teacher.parameters():
        p.requires_grad_(False)

    hist = [{"round": 0, "cer": c0}]
    for r in range(1, a.rounds + 1):
        keep, ids, pcer = make_pseudo(teacher, cal, cs, dev, a.quantile)
        if len(keep) < 4:
            print(f"[{a.user}] round {r}: too few kept ({len(keep)})")
            break
        done, loss = train_round(model, teacher, cal, keep, ids, cs, dev,
                                 a.steps, a.lr, a.ema, params,
                                 shuffle_labels=(a.mode == "shuffled"),
                                 seed=a.seed + r)
        cer = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A", ea,
                        dev).cer
        hist.append({"round": r, "cer": cer, "kept": len(keep),
                     "pseudo_cer": pcer, "loss": loss, "steps": done})
        print(f"[{a.user}] round {r}: kept {len(keep)}/{len(cal)} at "
              f"pseudo-CER {pcer:.2f} | loss {loss:.3f} | CER {cer:.2f} "
              f"(vs unadapted {base - cer:+.2f})", flush=True)
        json.dump({"args": vars(a), "base": base, "stage0": c0,
                   "hist": hist}, open(a.out, "w"), indent=1)

    final = hist[-1]["cer"]
    print(f"\n[RESULT] {a.user} mode={a.mode}: {base:.2f} -> {final:.2f} "
          f"(gain {base - final:+.2f}), ZERO labels", flush=True)
    json.dump({"args": vars(a), "base": base, "stage0": c0, "hist": hist,
               "final": final, "gain": base - final},
              open(a.out, "w"), indent=1)


if __name__ == "__main__":
    main()
