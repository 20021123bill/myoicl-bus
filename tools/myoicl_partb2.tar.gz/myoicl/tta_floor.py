# Copyright (c) 2026 MyoICL authors. MIT License.
"""W1 of Align-then-Adapt: measure the FLOOR that Part B must beat.

Before writing an LM-as-Teacher pipeline, we need the two cheap, well-known
test-time adaptation recipes measured on this exact benchmark, because every
later claim is "our TTA beats generic TTA" and that sentence is empty without
these two numbers:

    BN-recalib  recompute the model's own normalisation running statistics on
                the new user's UNLABELLED data. No gradients, no labels.
    Tent        entropy minimisation on the normalisation affine parameters
                only (Wang et al., ICLR 2021). No labels.

RELEVANT PRIOR RESULT FROM THIS PROJECT, so nobody re-runs it by accident:
Euclidean Alignment -- whitening the INPUT covariance toward the training
population -- was measured on this same frozen official checkpoint and is
catastrophic: 55.39 -> 99.25 CER (`full`), ~88-99 (`diag`), ~80 (`full` with
shrinkage 0.3). Recorded diagnosis: EA is a train+test protocol and cannot be
bolted test-only onto a model trained on unwhitened data. BN-recalib is a
different animal -- it adapts the model's own statistics rather than
transforming the input -- but the EA result is a standing warning that this
model is brittle to distribution surgery, so this script measures rather than
assumes, and reports every arm even when it loses.

SANITY GATE, non-negotiable: the unadapted mean over the 8 official test users
must reproduce 55.39 +- 1.0. If it does not, the checkpoint or the eval path
is wrong and every other number in the run is meaningless -- the script exits
instead of printing a table that would be believed.
"""
from __future__ import annotations

import argparse
import copy
import json
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


def norm_inventory(model):
    """What is actually adaptable in this architecture? Print, never assume."""
    bn, ln, other = [], [], []
    for name, m in model.named_modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
            bn.append(name)
        elif isinstance(m, nn.LayerNorm):
            ln.append(name)
        elif isinstance(m, (nn.GroupNorm, nn.InstanceNorm1d,
                            nn.InstanceNorm2d)):
            other.append(name)
    return {"batchnorm": bn, "layernorm": ln, "other_norm": other}


def unlabelled_windows(repo_root, data_root, ucfg, n_windows, window_length,
                       padding, seed=0):
    """Windows from the user's own calibration sessions. Labels are loaded by
    the dataset but this script never reads them -- the adaptation is
    label-free, and that is the whole point of Part B."""
    from .episodes import build_windowed_dataset
    from .qwerty_data import load_user_sessions

    s = load_user_sessions(repo_root, ucfg, data_root)
    pairs = [(None, p) for _, p in s["train"]]
    if not pairs:
        return []
    ds = build_windowed_dataset(pairs, train=False,
                                window_length=window_length,
                                padding=tuple(padding), raw=False)
    if len(ds) == 0:
        return []
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(ds))[:n_windows]
    return [ds[int(i)] for i in idx]


def _forward_batches(model, samples, device, batch_size, bf16, grad=False):
    from .episodes import windowed_collate
    from torch.utils.data import DataLoader

    dl = DataLoader(samples, batch_size=batch_size, shuffle=False,
                    collate_fn=windowed_collate)
    for b in dl:
        x = b["inputs"].to(device)
        ctx = torch.enable_grad() if grad else torch.no_grad()
        with ctx:
            with torch.autocast(device_type=device.type,
                                dtype=torch.bfloat16, enabled=bf16):
                em = model(x)
        yield b, em


def bn_recalibrate(model, samples, device, batch_size=4, bf16=False):
    """Recompute BatchNorm running stats on this user's unlabelled data.

    momentum=None makes each BN accumulate a CUMULATIVE average over the pass,
    so the result is the user's true statistics rather than an exponentially
    weighted tail dominated by the last batch.
    """
    bns = [m for m in model.modules()
           if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d))]
    if not bns:
        return 0
    old_mom = []
    for m in bns:
        old_mom.append(m.momentum)
        m.reset_running_stats()
        m.momentum = None
        m.train()
    for _ in _forward_batches(model, samples, device, batch_size, bf16):
        pass
    for m, mom in zip(bns, old_mom):
        m.momentum = mom
        m.eval()
    return len(bns)


def tent_adapt(model, samples, device, steps=50, lr=1e-3, batch_size=4,
               bf16=False):
    """Entropy minimisation on normalisation affine parameters only."""
    params = []
    for m in model.modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d,
                          nn.LayerNorm, nn.GroupNorm)):
            for p in (m.weight, m.bias):
                if p is not None:
                    p.requires_grad_(True)
                    params.append(p)
    if not params:
        return 0, float("nan")
    for p in model.parameters():
        if not any(p is q for q in params):
            p.requires_grad_(False)
    opt = torch.optim.Adam(params, lr=lr)
    done, last = 0, float("nan")
    while done < steps:
        for _, em in _forward_batches(model, samples, device, batch_size,
                                      bf16, grad=True):
            # em is log-probs (T, N, K)
            logp = em.float()
            ent = -(logp.exp() * logp).sum(-1).mean()
            opt.zero_grad(set_to_none=True)
            ent.backward()
            nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            last = float(ent)
            done += 1
            if done >= steps:
                break
    for p in model.parameters():
        p.requires_grad_(False)
    return len(params), last


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--ckpt", default=None,
                    help="official generic.ckpt; default: from the config's "
                         "init_backbone_from")
    ap.add_argument("--cal-windows", type=int, default=64,
                    help="unlabelled windows per user used for adaptation")
    ap.add_argument("--tent-steps", type=int, default=50)
    ap.add_argument("--tent-lr", type=float, default=1e-3)
    ap.add_argument("--arms", nargs="+",
                    default=["base", "bn", "tent", "bn+tent"])
    ap.add_argument("--users", nargs="+", default=None)
    ap.add_argument("--sanity-target", type=float, default=55.39)
    ap.add_argument("--sanity-tol", type=float, default=1.0)
    ap.add_argument("--out", default="/data2/chenyuxiang/runs/tta_floor.json")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import yaml
    from emg2qwerty.charset import charset as charset_fn

    from .eval_qwerty import eval_user
    from .model import build_model
    from .pretrained import load_official_backbone
    from .qwerty_data import test_user_configs

    cfg = yaml.safe_load(open(a.config))
    users = a.users or test_user_configs()
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    ck = a.ckpt or cfg.get("init_backbone_from")
    load_official_backbone(model, ck)
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)

    inv = norm_inventory(model)
    print(f"[arch] BatchNorm x{len(inv['batchnorm'])}: "
          f"{inv['batchnorm'][:4]}")
    print(f"[arch] LayerNorm x{len(inv['layernorm'])} | other norm "
          f"x{len(inv['other_norm'])}")
    if not inv["batchnorm"]:
        print("[arch] NOTE: no BatchNorm in this model -- the 'bn' arm is a "
              "no-op by construction and will read exactly as 'base'. That is "
              "an architecture fact, not a null result.")

    # eval_user's argparse namespace, values copied from eval_qwerty defaults
    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    clean = copy.deepcopy(model.state_dict())
    results = {arm: {} for arm in a.arms}

    for u in users:
        cal = unlabelled_windows(a.repo_root, a.data_root, u, a.cal_windows,
                                 ea.window_length, ea.padding, a.seed)
        print(f"\n[{u}] {len(cal)} unlabelled calibration windows "
              f"({len(cal) * ea.window_length / 2000 / 60:.1f} min)")
        for arm in a.arms:
            model.load_state_dict(clean)
            model.eval()
            if arm in ("bn", "bn+tent") and cal:
                n = bn_recalibrate(model, cal, dev, bf16=ea.bf16)
                print(f"  [{arm}] recalibrated {n} BatchNorm layers")
            if arm in ("tent", "bn+tent") and cal:
                n, ent = tent_adapt(model, cal, dev, steps=a.tent_steps,
                                    lr=a.tent_lr, bf16=ea.bf16)
                print(f"  [{arm}] tent: {n} affine params, final entropy "
                      f"{ent:.4f}")
            model.eval()
            acc = eval_user(model, cs, u, a.repo_root, a.data_root, "A", ea,
                            dev)
            results[arm][u] = acc.cer
            print(f"  [{arm}] {u}: CER {acc.cer:.2f}", flush=True)

        # SANITY GATE as early as possible: check after the first user that
        # the unadapted path is even on the published curve.
        if u == users[0] and "base" in results:
            b0 = results["base"][u]
            if not (20.0 <= b0 <= 90.0):
                raise SystemExit(
                    f"[FATAL] unadapted CER {b0:.2f} on {u} is not a "
                    f"plausible generic number. The checkpoint or the eval "
                    f"path is wrong; refusing to produce a table.")

    print("\n" + "=" * 60)
    print("TEST-TIME ADAPTATION FLOOR -- 8 official unseen users, NO labels")
    print(f"{'arm':>10} {'mean CER':>9} {'vs base':>9}")
    base_mean = float(np.mean(list(results["base"].values()))) \
        if "base" in results else float("nan")
    summary = {}
    for arm in a.arms:
        vals = list(results[arm].values())
        if not vals:
            continue
        m = float(np.mean(vals))
        summary[arm] = m
        print(f"{arm:>10} {m:>9.2f} {base_mean - m:>+9.2f}")

    print()
    if "base" in summary:
        d = abs(summary["base"] - a.sanity_target)
        if d > a.sanity_tol:
            print(f"[SANITY FAIL] unadapted mean {summary['base']:.2f} vs "
                  f"reproduction reference {a.sanity_target:.2f} "
                  f"(|d| = {d:.2f} > {a.sanity_tol}). Do NOT use the numbers "
                  f"above; fix the eval path first.")
        else:
            print(f"[SANITY OK] unadapted mean {summary['base']:.2f} "
                  f"reproduces {a.sanity_target:.2f}. The eval path is the "
                  f"published one, so the arms below are comparable to the "
                  f"literature.")
    best = min((v, k) for k, v in summary.items() if k != "base") \
        if len(summary) > 1 else None
    if best and "base" in summary:
        v, k = best
        print(f"\n[FLOOR] the best label-free generic recipe is '{k}' at "
              f"{v:.2f} ({summary['base'] - v:+.2f} vs unadapted).")
        print(f"        Part B (LM-as-Teacher) must beat {v:.2f}, not "
              f"{summary['base']:.2f}, to claim anything.")
        print(f"        Personalised-with-labels reference: 11.28 -- the gap "
              f"still open after the floor is {v - 11.28:.2f} CER.")

    json.dump({"args": vars(a), "arch": inv, "per_user": results,
               "summary": summary}, open(a.out, "w"), indent=1)
    print(f"\n[saved] {a.out}")


if __name__ == "__main__":
    main()
