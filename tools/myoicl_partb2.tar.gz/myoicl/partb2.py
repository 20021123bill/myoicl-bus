# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part B v2: filters that actually filter, each validated before it is used.

v1 produced "GATE FAILS", but for three reasons that were all mine:

  1. the confidence filter kept 100% of windows at threshold 0.85, because it
     averaged max-posterior over ALL frames and CTC output is dominated by
     blank frames whose posterior is ~1. The statistic carried no information.
     Fixed: confidence is measured over NON-BLANK frames only, and three other
     statistics are computed alongside it.
  2. the beam decoder was reported missing because ctc_beam.yaml nests its
     _target_ under a `decoder:` key and v1 read the top level. flashlight is
     genuinely absent, but kenlm and torchaudio are both installed, so the
     beam search is rebuilt on torchaudio's lexicon-free CTC decoder with the
     repo's own 6-gram character LM.
  3. nothing validated either the LM or the decoder, so a mis-tokenised LM
     would have silently produced a garbage filter.

Every filter here must PASS A VALIDATION before it is allowed to vote:
  * the LM must score real English text better than the same characters
    shuffled -- otherwise the tokenisation is wrong and perplexity is noise;
  * the beam decoder must beat greedy CER on a probe batch -- otherwise its
    configuration is wrong and its transcripts are worse than what we have.
A filter that fails validation is reported as DISABLED, never silently used.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import random
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


# ---------------------------------------------------------------- LM ------
class CharLM:
    """emg2qwerty's 6-gram character LM, via kenlm, with its tokenisation
    validated rather than assumed."""

    def __init__(self, path):
        import kenlm

        self.m = kenlm.Model(path)
        self.ok, self.note = self._validate()

    @staticmethod
    def _tok(text):
        # flashlight-style char LM: characters separated by spaces, word
        # boundary as '|'
        return " ".join("|" if c == " " else c for c in text.strip())

    def score(self, text):
        if not text:
            return 0.0
        t = self._tok(text)
        n = max(len(t.split()), 1)
        return self.m.score(t, bos=True, eos=True) / n      # log10 per token

    def _validate(self):
        good = "the quick brown fox jumps over the lazy dog"
        chars = list(good.replace(" ", ""))
        random.Random(0).shuffle(chars)
        bad = "".join(chars)
        sg, sb = self.score(good), self.score(bad)
        if sg > sb + 0.05:
            return True, f"validated: real {sg:.3f} > shuffled {sb:.3f}"
        return False, (f"FAILED: real {sg:.3f} vs shuffled {sb:.3f} -- "
                       f"tokenisation is probably wrong, LM filter disabled")


# ------------------------------------------------------------- decoder ----
def build_torchaudio_beam(cs, lm_path, beam_size=50, lm_weight=2.0,
                          word_score=0.0):
    """Lexicon-free CTC beam search on torchaudio, using the repo's char LM.

    Returns (decode_fn, info) or (None, reason). flashlight-text is absent on
    this machine, which is why the official CTCBeamDecoder cannot be used.
    """
    try:
        from torchaudio.models.decoder import ctc_decoder
    except Exception as e:                                   # noqa: BLE001
        return None, f"torchaudio ctc_decoder unavailable: {e}"

    from emg2qwerty.data import LabelData

    V = cs.num_classes
    tokens = []
    for i in range(V):
        if i == cs.null_class:
            tokens.append("-")
            continue
        try:
            t = LabelData.from_labels([i]).text
        except Exception:                                    # noqa: BLE001
            t = f"<{i}>"
        tokens.append("|" if t == " " else (t if len(t) == 1 else f"<{i}>"))
    try:
        dec = ctc_decoder(lexicon=None, tokens=tokens, lm=lm_path,
                          nbest=1, beam_size=beam_size, lm_weight=lm_weight,
                          word_score=word_score, blank_token="-",
                          sil_token="|", unk_word="<unk>")
    except Exception as e:                                   # noqa: BLE001
        return None, f"ctc_decoder construction failed: {e}"

    def run(emissions, lengths):
        """emissions (N, T, K) float cpu -> list[str]"""
        hyps = dec(emissions, lengths)
        out = []
        for h in hyps:
            if not h:
                out.append("")
                continue
            toks = [tokens[i] for i in h[0].tokens
                    if 0 <= i < len(tokens)]
            out.append("".join(" " if t == "|" else t for t in toks
                               if t != "-"))
        return out

    return run, f"torchaudio lexicon-free beam (size {beam_size}, lm_w {lm_weight})"


# -------------------------------------------------------------- stats -----
def window_stats(em, length, blank):
    """em (T, K) log-probs for ONE window -> confidence statistics.

    Every statistic here excludes blank frames, which is the fix for v1's
    no-op filter: blanks dominate CTC output and their posterior is ~1.
    """
    lp = em[:int(length)]
    p = lp.exp()
    top = p.max(-1)
    arg = top.indices
    conf = top.values
    nb = arg != blank
    n_nb = int(nb.sum())
    if n_nb == 0:
        return {"conf_nb": 0.0, "n_chars": 0, "path_lp": float(lp.max(-1)
                                                               .values.mean()),
                "ent_nb": 0.0}
    ent = -(p * lp).sum(-1)
    return {
        "conf_nb": float(conf[nb].mean()),        # mean posterior of emitted
        "n_chars": n_nb,
        "path_lp": float(top.values.log().mean()),
        "ent_nb": float(ent[nb].mean()),
    }


def augmented_views(x, n=2, seed=0):
    """Label-preserving views of a log-spectrogram batch (T, N, B, C, F)."""
    g = torch.Generator(device="cpu").manual_seed(seed)
    out = []
    for i in range(n):
        v = x.clone()
        if i == 0:
            v = v + 0.10 * torch.randn(v.shape, generator=g).to(v.device)
        else:
            v = torch.roll(v, shifts=(i + 1), dims=0)
        out.append(v)
    return out


# ---------------------------------------------------------------- main ----
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--users", nargs="+", default=None)
    ap.add_argument("--cal-windows", type=int, default=128)
    ap.add_argument("--beam-size", type=int, default=50)
    ap.add_argument("--lm-weight", type=float, default=2.0)
    ap.add_argument("--n-views", type=int, default=2)
    ap.add_argument("--audit-only", action="store_true")
    ap.add_argument("--adapt-filter", default="auto",
                    help="which filter's kept set to train on; 'auto' picks "
                         "the validated filter with lowest pseudo-CER at "
                         ">=10%% retention")
    ap.add_argument("--steps", type=int, default=300)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--ema", type=float, default=0.999)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import yaml
    from emg2qwerty.charset import charset as charset_fn
    from emg2qwerty.data import LabelData
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate
    from .eval_qwerty import eval_user
    from .metrics import CERAccumulator, greedy_ctc_decode
    from .model import build_model
    from .partb import self_train
    from .pretrained import load_official_backbone
    from .qwerty_data import test_user_configs
    from .tta_floor import unlabelled_windows

    cfg = yaml.safe_load(open(a.config))
    users = a.users or test_user_configs()
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()

    # ---- LM, validated -----------------------------------------------
    lm_path = os.path.join(a.repo_root, "models", "lm",
                           "wikitext-103-6gram-charlm.bin")
    lm = None
    if os.path.exists(lm_path):
        try:
            lm = CharLM(lm_path)
            print(f"[lm] {lm_path}\n[lm] {lm.note}")
            if not lm.ok:
                lm = None
        except Exception as e:                               # noqa: BLE001
            print(f"[lm] load failed: {e}")
    else:
        print(f"[lm] MISSING at {lm_path}")

    # ---- beam decoder, validated later against greedy ------------------
    beam_fn, beam_info = (None, "not attempted")
    if lm is not None:
        beam_fn, beam_info = build_torchaudio_beam(
            cs, lm_path, a.beam_size, a.lm_weight)
    print(f"[beam] {beam_info}")

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, cfg.get("init_backbone_from"))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    clean = copy.deepcopy(model.state_dict())

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    def cer_of(pred, true):
        acc = CERAccumulator()
        for p_, t_ in zip(pred, true):
            acc.update(p_, t_)
        return acc.cer

    out = {"args": vars(a), "lm_ok": lm is not None, "beam": beam_info,
           "users": {}}
    beam_validated = None

    for u in users:
        cal = unlabelled_windows(a.repo_root, a.data_root, u, a.cal_windows,
                                 ea.window_length, ea.padding, a.seed)
        if not cal:
            print(f"[{u}] no windows"); continue
        model.load_state_dict(clean); model.eval()

        recs = []
        dl = DataLoader(cal, batch_size=4, shuffle=False,
                        collate_fn=windowed_collate)
        with torch.no_grad():
            for b in dl:
                x = b["inputs"].to(dev)
                em = model(x).float()                        # (T, N, K)
                lens = torch.full((em.shape[1],), em.shape[0],
                                  dtype=torch.long)
                g = greedy_ctc_decode(em, lens, blank=cs.null_class)
                views = []
                for v in augmented_views(x, a.n_views, a.seed):
                    ev = model(v).float()
                    views.append(greedy_ctc_decode(ev, lens,
                                                   blank=cs.null_class))
                beams = None
                if beam_fn is not None:
                    try:
                        beams = beam_fn(em.permute(1, 0, 2).cpu(),
                                        lens.cpu())
                    except Exception as e:                   # noqa: BLE001
                        print(f"[beam] runtime failure, disabling: "
                              f"{str(e)[:100]}")
                        beam_fn = None
                tg, tl = b["targets"].numpy(), b["target_lengths"].numpy()
                for n in range(em.shape[1]):
                    st = window_stats(em[:, n], int(lens[n]), cs.null_class)
                    r = dict(st)
                    r["greedy"] = LabelData.from_labels(g[n]).text
                    r["ids"] = list(map(int, g[n]))
                    r["true"] = LabelData.from_labels(tg[: tl[n], n]).text
                    r["consistent"] = all(
                        LabelData.from_labels(vv[n]).text == r["greedy"]
                        for vv in views)
                    if beams is not None:
                        r["beam"] = beams[n]
                    if lm is not None:
                        r["lm"] = lm.score(r["greedy"])
                    recs.append(r)

        N = len(recs)
        true = [r["true"] for r in recs]

        # ---- validate the beam decoder before letting it filter --------
        if beam_validated is None and any("beam" in r for r in recs):
            bs = [r for r in recs if "beam" in r]
            cg = cer_of([r["greedy"] for r in bs], [r["true"] for r in bs])
            cb = cer_of([r["beam"] for r in bs], [r["true"] for r in bs])
            beam_validated = cb < cg
            print(f"[beam] validation: greedy {cg:.2f} vs beam {cb:.2f} -> "
                  f"{'USABLE' if beam_validated else 'DISABLED (worse than greedy)'}")
            out["beam_validation"] = {"greedy": cg, "beam": cb,
                                      "usable": bool(beam_validated)}

        conf_q = np.quantile([r["conf_nb"] for r in recs], [0.5, 0.75, 0.9])
        lp_q = np.quantile([r["path_lp"] for r in recs], [0.5, 0.75, 0.9])

        arms = {}

        def add(name, sel, key="greedy"):
            idx = [i for i in range(N) if sel(recs[i])]
            arms[name] = {
                "n": len(idx), "retention": len(idx) / max(N, 1),
                "cer": (cer_of([recs[i][key] for i in idx],
                               [true[i] for i in idx]) if idx else float("nan")),
                "idx": idx,
            }

        add("all_greedy", lambda r: True)
        # thresholds are DATA-DRIVEN quantiles, not magic constants -- v1's
        # fixed 0.85 kept everything because the statistic was mis-scaled
        for q, thr in zip((50, 75, 90), conf_q):
            add(f"conf_nb>q{q}", lambda r, t=thr: r["conf_nb"] >= t)
        for q, thr in zip((50, 75, 90), lp_q):
            add(f"path_lp>q{q}", lambda r, t=thr: r["path_lp"] >= t)
        add("consistent", lambda r: r["consistent"])
        add("consistent+conf75",
            lambda r, t=conf_q[1]: r["consistent"] and r["conf_nb"] >= t)
        if lm is not None:
            lq = np.quantile([r["lm"] for r in recs], 0.75)
            add("lm>q75", lambda r, t=lq: r["lm"] >= t)
            add("consistent+lm75",
                lambda r, t=lq: r["consistent"] and r["lm"] >= t)
        if beam_validated:
            add("agree", lambda r: r.get("beam") == r.get("greedy"))
            add("agree+conf75",
                lambda r, t=conf_q[1]: r.get("beam") == r.get("greedy")
                and r["conf_nb"] >= t)

        print(f"\n[{u}] {N} windows | raw CER {arms['all_greedy']['cer']:.2f}")
        for k, v in arms.items():
            if k == "all_greedy" or not v["n"]:
                continue
            print(f"   {k:>20}: keep {v['retention']:5.1%}  "
                  f"pseudo-CER {v['cer']:6.2f}  "
                  f"(gain {arms['all_greedy']['cer'] - v['cer']:+6.2f})")

        pick = None
        if a.adapt_filter == "auto":
            cand = [(v["cer"], k) for k, v in arms.items()
                    if k != "all_greedy" and v["retention"] >= 0.10
                    and v["n"] >= 8 and not np.isnan(v["cer"])]
            pick = min(cand)[1] if cand else None
        elif a.adapt_filter in arms:
            pick = a.adapt_filter
        rec_out = {k: {kk: vv for kk, vv in v.items() if kk != "idx"}
                   for k, v in arms.items()}
        out["users"][u] = {"arms": rec_out, "picked": pick}

        if a.audit_only or pick is None:
            json.dump(out, open(a.out, "w"), indent=1)
            continue

        keep = arms[pick]["idx"]
        print(f"   -> adapting on '{pick}': {len(keep)} windows at "
              f"{arms[pick]['cer']:.2f} pseudo-CER")
        teacher = copy.deepcopy(model)
        for p in teacher.parameters():
            p.requires_grad_(False)
        n_par, last = self_train(model, teacher, cal, keep,
                                 [r["ids"] for r in recs], cs, dev,
                                 steps=a.steps, lr=a.lr, ema=a.ema,
                                 bf16=ea.bf16)
        model.eval()
        after = eval_user(model, cs, u, a.repo_root, a.data_root, "A", ea,
                          dev).cer
        model.load_state_dict(clean); model.eval()
        before = eval_user(model, cs, u, a.repo_root, a.data_root, "A", ea,
                           dev).cer
        out["users"][u]["adapt"] = {"before": before, "after": after,
                                    "gain": before - after,
                                    "filter": pick, "kept": len(keep),
                                    "params": n_par, "last_loss": last}
        print(f"   [ADAPT] {u}: {before:.2f} -> {after:.2f} "
              f"(gain {before - after:+.2f}) with ZERO labels", flush=True)
        json.dump(out, open(a.out, "w"), indent=1)

    json.dump(out, open(a.out, "w"), indent=1)
    print(f"\n[saved] {a.out}")


if __name__ == "__main__":
    main()
