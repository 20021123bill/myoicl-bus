# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part B: LM-as-Teacher test-time adaptation, and the gate that predicts it.

THE GATE, measured on the way in rather than after two weeks of building:
self-training works only if the pseudo-labels that survive filtering are much
more accurate than the raw decode. On an unseen user the generic model decodes
at ~55 CER; training on 55%-wrong transcripts reinforces errors. So the first
thing this script prints is

    CER(all pseudo-labels)  vs  CER(pseudo-labels that pass the filter)
    and the retention rate

If the filter buys a large accuracy gain at a usable retention rate, Part B
will work and the adaptation that follows in the same run should show it. If
the filtered set is still ~40 CER, self-training will amplify its own errors
and the filter -- not the optimiser -- is what needs work. Either way the
answer arrives in one run.

The ground-truth labels of the adaptation sessions are read ONLY to compute
that diagnostic number. Adaptation itself uses pseudo-labels exclusively;
`--audit-only` proves the pipeline never needs the labels at all.

Filters (the plan's triple filter; each is reported separately so a dead one
is visible rather than diluted):
  agree  LM-beam transcript == greedy transcript
  conf   mean max-posterior over frames >= threshold
  ppl    LM perplexity of the transcript <= threshold
"""
from __future__ import annotations

import argparse
import copy
import json
import os
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


# --------------------------------------------------------------------------
# decoder plumbing: the official beam decoder is a hard dependency of the
# plan's Part B, so find out in five minutes whether it is usable here.
# --------------------------------------------------------------------------
def build_beam_decoder(repo_root, charset_obj, verbose=True):
    """Instantiate emg2qwerty's beam decoder from its own hydra yaml.

    Returns (decoder, info_string) or (None, reason).
    """
    import importlib

    import yaml

    cfg_path = os.path.join(repo_root, "config", "decoder", "ctc_beam.yaml")
    if not os.path.exists(cfg_path):
        return None, f"no decoder config at {cfg_path}"
    cfg = yaml.safe_load(open(cfg_path)) or {}
    target = cfg.pop("_target_", None)
    if not target:
        return None, f"{cfg_path} has no _target_"
    mod_name, cls_name = target.rsplit(".", 1)
    try:
        cls = getattr(importlib.import_module(mod_name), cls_name)
    except Exception as e:                                # noqa: BLE001
        return None, f"import {target} failed: {e}"
    # resolve relative lm paths against the repo root
    for k, v in list(cfg.items()):
        if isinstance(v, str) and ("lm" in k or "path" in k):
            p = v if os.path.isabs(v) else os.path.join(repo_root, v)
            cfg[k] = p
            if not os.path.exists(p):
                return None, f"LM asset missing: {k}={p}"
    try:
        dec = cls(charset=charset_obj, **cfg)
    except TypeError:
        try:
            dec = cls(**cfg)
        except Exception as e:                            # noqa: BLE001
            return None, f"construct {cls_name} failed: {e}"
    except Exception as e:                                # noqa: BLE001
        return None, f"construct {cls_name} failed: {e}"
    if verbose:
        print(f"[decoder] {target} built from {cfg_path} | kwargs "
              f"{ {k: (str(v)[:40]) for k, v in cfg.items()} }")
    return dec, target


def decode_beam(dec, emissions, length):
    """emissions (T, K) float numpy/tensor for ONE utterance -> label ids."""
    e = emissions.detach().float().cpu().numpy()[:int(length)]
    for name in ("decode", "__call__"):
        fn = getattr(dec, name, None)
        if fn is None:
            continue
        try:
            out = fn(e)
        except TypeError:
            try:
                out = fn(emissions=e)
            except Exception:                             # noqa: BLE001
                continue
        except Exception:                                 # noqa: BLE001
            continue
        if hasattr(dec, "reset"):
            try:
                dec.reset()
            except Exception:                             # noqa: BLE001
                pass
        return out
    raise RuntimeError("beam decoder exposes neither decode() nor __call__()")


# --------------------------------------------------------------------------
def collect_pseudo(model, samples, cs, dev, beam_dec, batch_size=4,
                   bf16=False, conf_thr=0.85, use_labels_for_audit=True):
    """Decode unlabelled windows; return per-window records.

    Each record: greedy text, beam text (if available), mean max-posterior,
    the pseudo-label ids used for training, and -- for the audit only -- the
    true text.
    """
    from emg2qwerty.data import LabelData
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate
    from .metrics import greedy_ctc_decode

    dl = DataLoader(samples, batch_size=batch_size, shuffle=False,
                    collate_fn=windowed_collate)
    recs = []
    model.eval()
    with torch.no_grad():
        for b in dl:
            x = b["inputs"].to(dev)
            with torch.autocast(device_type=dev.type, dtype=torch.bfloat16,
                                enabled=bf16):
                em = model(x)
            em = em.float()                                   # (T, N, K)
            lens = b.get("output_lengths")
            if lens is None:
                lens = torch.full((em.shape[1],), em.shape[0],
                                  dtype=torch.long)
            probs = em.exp()
            conf = probs.max(-1).values                       # (T, N)
            greedy = greedy_ctc_decode(em, lens.cpu(), blank=cs.null_class)
            tg = b["targets"].numpy()
            tl = b["target_lengths"].numpy()
            for n in range(em.shape[1]):
                L = int(lens[n])
                g_ids = greedy[n]
                rec = {
                    "greedy": LabelData.from_labels(g_ids).text,
                    "conf": float(conf[:L, n].mean()),
                    "ids": list(map(int, g_ids)),
                    "len": L,
                }
                if beam_dec is not None:
                    try:
                        b_ids = decode_beam(beam_dec, em[:, n], L)
                        if hasattr(b_ids, "text"):
                            rec["beam"] = b_ids.text
                            rec["beam_ids"] = list(getattr(b_ids, "labels",
                                                           []))
                        else:
                            rec["beam"] = LabelData.from_labels(b_ids).text
                            rec["beam_ids"] = list(map(int, b_ids))
                    except Exception as e:                    # noqa: BLE001
                        rec["beam_error"] = str(e)[:120]
                if use_labels_for_audit:
                    rec["true"] = LabelData.from_labels(
                        tg[: tl[n], n]).text
                recs.append(rec)
    return recs


def cer_of(pred, true):
    from .metrics import CERAccumulator

    acc = CERAccumulator()
    for p, t in zip(pred, true):
        acc.update(p, t)
    return acc.cer


def audit(recs, conf_thr):
    """The gate. Returns a dict of arm -> (n, retention, CER)."""
    has_beam = any("beam" in r for r in recs)
    out = {}
    true = [r.get("true", "") for r in recs]
    N = len(recs)

    def arm(name, keep, textkey):
        sel = [i for i in range(N) if keep(recs[i])]
        if not sel:
            out[name] = {"n": 0, "retention": 0.0, "cer": float("nan")}
            return
        out[name] = {
            "n": len(sel),
            "retention": len(sel) / max(N, 1),
            "cer": cer_of([recs[i][textkey] for i in sel],
                          [true[i] for i in sel]),
        }

    arm("all_greedy", lambda r: True, "greedy")
    if has_beam:
        arm("all_beam", lambda r: "beam" in r, "beam")
        arm("agree", lambda r: r.get("beam") == r.get("greedy"), "greedy")
        arm("agree+conf",
            lambda r: r.get("beam") == r.get("greedy")
            and r["conf"] >= conf_thr, "greedy")
    arm("conf", lambda r: r["conf"] >= conf_thr, "greedy")
    return out, has_beam


def self_train(model, teacher, samples, keep_idx, pseudo_ids, cs, dev,
               steps=200, lr=1e-3, batch_size=4, ema=0.999, bf16=False):
    """CTC self-training on filtered pseudo-labels; norm affine params only."""
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate

    params = []
    for m in model.modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.LayerNorm,
                          nn.GroupNorm)):
            for p in (m.weight, m.bias):
                if p is not None:
                    p.requires_grad_(True)
                    params.append(p)
    if not params or not keep_idx:
        return 0, float("nan")
    ids_of = {i: pseudo_ids[i] for i in keep_idx}
    sub = [samples[i] for i in keep_idx]
    opt = torch.optim.Adam(params, lr=lr)
    dl = DataLoader(sub, batch_size=batch_size, shuffle=True,
                    collate_fn=windowed_collate)
    order = list(keep_idx)
    done, last = 0, float("nan")
    model.train()
    while done < steps:
        for bi, b in enumerate(dl):
            x = b["inputs"].to(dev)
            with torch.autocast(device_type=dev.type, dtype=torch.bfloat16,
                                enabled=bf16):
                em = model(x)
            em = em.float()
            N = em.shape[1]
            chunk = order[bi * batch_size:(bi + 1) * batch_size][:N]
            tgt, tlen = [], []
            for i in chunk:
                s = [c for c in ids_of[i] if c != cs.null_class]
                tgt.append(torch.tensor(s, dtype=torch.long))
                tlen.append(len(s))
            if not tgt or min(tlen) == 0:
                continue
            maxl = max(tlen)
            T = torch.zeros(len(tgt), maxl, dtype=torch.long)
            for j, t in enumerate(tgt):
                T[j, : len(t)] = t
            in_len = torch.full((len(tgt),), em.shape[0], dtype=torch.long)
            loss = nn.functional.ctc_loss(
                em[:, : len(tgt)], T.to(dev), in_len.to(dev),
                torch.tensor(tlen).to(dev), blank=cs.null_class,
                zero_infinity=True)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(params, 1.0)
            opt.step()
            with torch.no_grad():
                for pt, ps in zip(teacher.parameters(), model.parameters()):
                    pt.mul_(ema).add_(ps.detach(), alpha=1 - ema)
            last = float(loss)
            done += 1
            if done >= steps:
                break
    model.eval()
    return len(params), last


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--ckpt", default=None)
    ap.add_argument("--users", nargs="+", default=None)
    ap.add_argument("--cal-windows", type=int, default=96)
    ap.add_argument("--conf-thr", type=float, default=0.85)
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--ema", type=float, default=0.999)
    ap.add_argument("--audit-only", action="store_true",
                    help="stop after the gate; no adaptation")
    ap.add_argument("--filter", default="agree+conf",
                    help="which arm's kept set to train on")
    ap.add_argument("--out", default="/data2/chenyuxiang/runs/partb.json")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import yaml
    from emg2qwerty.charset import charset as charset_fn

    from .eval_qwerty import eval_user
    from .model import build_model
    from .pretrained import load_official_backbone
    from .qwerty_data import test_user_configs
    from .tta_floor import unlabelled_windows

    cfg = yaml.safe_load(open(a.config))
    users = a.users or test_user_configs()
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, a.ckpt or cfg.get("init_backbone_from"))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    clean = copy.deepcopy(model.state_dict())

    beam_dec, info = build_beam_decoder(a.repo_root, cs)
    if beam_dec is None:
        print(f"[decoder] NO BEAM DECODER: {info}")
        print("[decoder] running with the confidence filter only. The "
              "'agree' filter is the plan's main one, so this is a "
              "DEPENDENCY GAP to fix, not a result about the method.")

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    per_user, adapted = {}, {}
    for u in users:
        cal = unlabelled_windows(a.repo_root, a.data_root, u, a.cal_windows,
                                 ea.window_length, ea.padding, a.seed)
        if not cal:
            print(f"[{u}] no calibration windows, skipped")
            continue
        model.load_state_dict(clean); model.eval()
        recs = collect_pseudo(model, cal, cs, dev, beam_dec,
                              bf16=ea.bf16, conf_thr=a.conf_thr)
        arms, has_beam = audit(recs, a.conf_thr)
        per_user[u] = arms
        print(f"\n[{u}] {len(recs)} unlabelled windows")
        for name, r in arms.items():
            print(f"   {name:>12}: n={r['n']:<4d} keep={r['retention']:5.1%} "
                  f"pseudo-CER {r['cer']:6.2f}")

        if a.audit_only:
            continue
        key = a.filter if a.filter in arms else "conf"
        keep = [i for i, r in enumerate(recs)
                if (r["conf"] >= a.conf_thr
                    and (not has_beam or r.get("beam") == r.get("greedy")))]
        if key == "conf":
            keep = [i for i, r in enumerate(recs) if r["conf"] >= a.conf_thr]
        teacher = copy.deepcopy(model)
        for p in teacher.parameters():
            p.requires_grad_(False)
        n_par, last = self_train(model, teacher, cal, keep,
                                 [r["ids"] for r in recs], cs, dev,
                                 steps=a.steps, lr=a.lr, ema=a.ema,
                                 bf16=ea.bf16)
        model.eval()
        cer_after = eval_user(model, cs, u, a.repo_root, a.data_root, "A",
                              ea, dev).cer
        model.load_state_dict(clean); model.eval()
        cer_before = eval_user(model, cs, u, a.repo_root, a.data_root, "A",
                               ea, dev).cer
        adapted[u] = {"before": cer_before, "after": cer_after,
                      "gain": cer_before - cer_after, "kept": len(keep),
                      "params": n_par, "last_loss": last}
        print(f"   [adapt] {u}: {cer_before:.2f} -> {cer_after:.2f} "
              f"(gain {cer_before - cer_after:+.2f}) on {len(keep)} "
              f"pseudo-labelled windows", flush=True)

    print("\n" + "=" * 66)
    print("THE GATE -- pseudo-label quality on unseen users (means)")
    names = sorted({n for v in per_user.values() for n in v})
    for n in names:
        rs = [v[n] for v in per_user.values() if n in v and v[n]["n"]]
        if not rs:
            continue
        print(f"  {n:>12}: keep {np.mean([r['retention'] for r in rs]):5.1%} "
              f"| pseudo-CER {np.mean([r['cer'] for r in rs]):6.2f}")
    base = [v["all_greedy"]["cer"] for v in per_user.values()
            if "all_greedy" in v]
    best_f = None
    for n in names:
        if n == "all_greedy":
            continue
        rs = [v[n] for v in per_user.values() if n in v and v[n]["n"]]
        if not rs:
            continue
        c, k = np.mean([r["cer"] for r in rs]), np.mean(
            [r["retention"] for r in rs])
        if k >= 0.05 and (best_f is None or c < best_f[1]):
            best_f = (n, c, k)
    if base and best_f:
        n, c, k = best_f
        print(f"\n  raw decode {np.mean(base):.2f} CER -> filter '{n}' keeps "
              f"{k:.1%} at {c:.2f} CER")
        if c < 25:
            print("  ==> GATE PASSES: the filter yields transcripts clean "
                  "enough to train on. Part B is viable.")
        elif c < 40:
            print("  ==> GATE MARGINAL: usable but the filter needs "
                  "tightening (thresholds / LM) before the optimiser is "
                  "blamed for anything.")
        else:
            print("  ==> GATE FAILS: self-training on these would reinforce "
                  "errors. Fix the FILTER, not the training loop.")
    if adapted:
        g = np.mean([v["gain"] for v in adapted.values()])
        b = np.mean([v["before"] for v in adapted.values()])
        print(f"\n  ADAPTATION: {b:.2f} -> {b - g:.2f} (mean gain {g:+.2f}) "
              f"with zero labels")
    json.dump({"args": vars(a), "audit": per_user, "adapted": adapted},
              open(a.out, "w"), indent=1)
    print(f"\n[saved] {a.out}")


if __name__ == "__main__":
    main()
