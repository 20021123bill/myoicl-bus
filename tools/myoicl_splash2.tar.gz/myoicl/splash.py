# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part A stage 0: the normalisation family, which two literatures agree is
the highest-value / lowest-cost way to close a cross-subject gap.

WHY THIS COMES BEFORE THE CONTRASTIVE LOSSES.

SplashNet (arXiv 2506.12356, NeurIPS 2025) ablates exactly our benchmark,
zero-shot cross-user on emg2qwerty:

    TDS baseline                                  51.78 CER
    + RSG   (spectral bands 33 -> 6)              47.18
    + RTN   (rolling time normalisation)          39.15   <- -12.6 alone
    + ACM   (aggressive channel masking)          36.42
    + split-and-share                             36.41
    + upscaled                                    35.67

RTN alone is worth about seven times everything Part B has produced (+1.7),
and it needs no labels and no calibration.

The EEG cross-subject survey (arXiv 2604.27033) reaches the same conclusion
independently: "subject-wise normalisation -- remarkably simple yet
effective", rated Excellent in both regimes at Very Low test-time cost with
no calibration required, while the feature-alignment family (where Euclidean
Alignment lives) is only "moderate ... can average out discriminative
patterns" -- which is precisely what we measured when EA took the frozen
official checkpoint from 55.39 to 99.25.

So this module implements the three preprocessing/augmentation pieces:

  RTN  causal online z-scoring of every input feature. Each frame is
       normalised by statistics accumulated from frames up to and including
       itself, so it is usable at test time and streaming-safe. A warmup
       count keeps the first frames from being divided by a near-zero
       variance.
  RSG  average adjacent frequency bins, 33 -> 6, reducing the feature count
       fivefold and discarding per-user spectral detail that does not
       transfer.
  ACM  training-time augmentation: zero more than half the electrodes and
       remove broad spectral chunks from the rest, forcing the model onto
       smaller, more universal feature sets.

RTN and RSG are applied at BOTH train and test time (they are part of the
model's input contract); ACM is train-only.
"""
from __future__ import annotations

import torch
from torch import nn


class RollingTimeNorm(nn.Module):
    """Causal online z-scoring over time, per feature.

    x: (T, N, bands, channels, freq)  ->  same shape.

    Statistics at frame t use frames 0..t only. Implemented with cumulative
    sums so it is exact rather than an EMA approximation, and identical
    whether the sequence arrives whole or in chunks of the same prefix.
    """

    def __init__(self, eps: float = 1e-5, warmup: int = 8):
        super().__init__()
        self.eps = eps
        self.warmup = warmup

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        T = x.shape[0]
        c = torch.arange(1, T + 1, device=x.device, dtype=x.dtype)
        shape = [T] + [1] * (x.dim() - 1)
        c = c.view(shape)
        s1 = torch.cumsum(x, dim=0)
        s2 = torch.cumsum(x * x, dim=0)
        mean = s1 / c
        var = (s2 / c - mean * mean).clamp_min(0.0)
        out = (x - mean) / (var + self.eps).sqrt()
        if self.warmup > 0:
            # the first frames have almost no history; leaving them raw would
            # inject a large-magnitude spike into an otherwise unit-scale
            # stream, so they are simply zeroed (mean-centred with no scale)
            k = min(self.warmup, T)
            out = out.clone()
            out[:k] = (x[:k] - mean[:k]) / (var[:k] + 1.0).sqrt()
        return out


class ReduceSpectralGranularity(nn.Module):
    """Average adjacent frequency bins: 33 -> n_out (default 6).

    x: (..., freq) -> (..., n_out). Any remainder bins are dropped rather
    than unevenly pooled, so every output band spans the same width.
    """

    def __init__(self, n_out: int = 6):
        super().__init__()
        self.n_out = n_out

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        F = x.shape[-1]
        w = F // self.n_out
        if w < 1:
            return x
        keep = w * self.n_out
        return x[..., :keep].reshape(*x.shape[:-1], self.n_out, w).mean(-1)


class AggressiveChannelMask(nn.Module):
    """Train-only augmentation: drop electrodes and spectral chunks.

    Zeroes `p_ch` of the electrodes (per sample, per band) and removes
    `n_freq_chunks` contiguous spectral chunks of width up to
    `freq_chunk` from the survivors.
    """

    def __init__(self, p_ch: float = 0.55, n_freq_chunks: int = 2,
                 freq_chunk: int = 2):
        super().__init__()
        self.p_ch = p_ch
        self.n_freq_chunks = n_freq_chunks
        self.freq_chunk = freq_chunk

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not self.training:
            return x
        # x: (T, N, bands, channels, freq)
        T, N, B, C, F = x.shape
        keep = (torch.rand(1, N, B, C, 1, device=x.device) >= self.p_ch)
        if keep.sum() == 0:                       # never mask everything
            keep = torch.ones_like(keep)
        x = x * keep
        for _ in range(self.n_freq_chunks):
            w = int(torch.randint(1, self.freq_chunk + 1, (1,)).item())
            f0 = int(torch.randint(0, max(1, F - w + 1), (1,)).item())
            x[..., f0:f0 + w] = 0.0
        return x


class SplashFrontend(nn.Module):
    """RSG -> RTN -> (ACM, train only). Drop-in before the spatial frontend.

    Order matters. RSG first, so normalisation statistics are computed on the
    features the model will actually consume rather than on 33 narrow bins
    that get averaged away afterwards. ACM last, so masked positions are
    exact zeros in normalised space -- which is the mean, i.e. "no evidence"
    -- rather than zeros in raw space, which after normalisation would be a
    large negative value and would teach the model that a dead electrode is a
    strong signal.
    """

    def __init__(self, n_bands_out: int = 6, use_rtn: bool = True,
                 use_acm: bool = True, p_ch: float = 0.55):
        super().__init__()
        self.rsg = ReduceSpectralGranularity(n_bands_out) if n_bands_out else None
        self.rtn = RollingTimeNorm() if use_rtn else None
        self.acm = AggressiveChannelMask(p_ch=p_ch) if use_acm else None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.rsg is not None:
            x = self.rsg(x)
        if self.rtn is not None:
            x = self.rtn(x)
        if self.acm is not None:
            x = self.acm(x)
        return x

    @property
    def out_freq_bins(self) -> int:
        return self.rsg.n_out if self.rsg is not None else 33
