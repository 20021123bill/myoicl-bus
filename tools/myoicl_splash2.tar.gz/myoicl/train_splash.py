# Copyright (c) 2026 MyoICL authors. MIT License.
"""Part A stage 0: retrain the official architecture WITH the normalisation
recipe, because retrofitting it is destructive.

Job 600 measured the retrofit on the frozen official checkpoint: 60.73 ->
94.89 CER, -34 points, the same failure mode as Euclidean Alignment
(55.39 -> 99.25). Normalisation that is part of the training contract cannot
be bolted on afterwards. So the recipe has to be trained in from scratch:

    RSG   spectral bands 33 -> 6      (SplashNet: 51.78 -> 47.18 alone)
    RTN   causal online z-scoring     (SplashNet: 51.78 -> 39.15 alone)
    ACM   aggressive channel masking  (SplashNet: + RTN -> 36.42)

Target: reproduce roughly 36-39 zero-shot CER on the 8 official test users,
against our own reproduction of the plain baseline at 55.39. That platform is
what the contrastive alignment (stage A1) then has to improve on, and it is
also what should push Part B's pseudo-labels below the ~45 crossover we
measured, where self-training starts paying instead of costing.

The architecture is the published one, only the input contract changes:
freq_bins 33 -> 6, and a SplashFrontend ahead of the spatial frontend.
Nothing here is claimed as ours -- this is the platform, and stage A1 is the
experiment.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import time

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader


def build_eval_windows(pairs, window_length=10000, cap=512, max_sessions=24,
                       seed=0):
    from .episodes import build_windowed_dataset

    seen, sub = set(), []
    for u, p in pairs:
        if u in seen:
            continue
        seen.add(u); sub.append((u, p))
        if len(sub) >= max_sessions:
            break
    if not sub:
        return None
    ds = build_windowed_dataset(sub, train=False, window_length=window_length,
                                padding=(1800, 200), raw=False)
    if len(ds) == 0:
        return None
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(ds))[:cap]
    return [ds[int(i)] for i in idx]


def cer_on(model, front, samples, cs, dev, bf16=True, batch_size=4):
    from emg2qwerty.data import LabelData

    from .episodes import windowed_collate
    from .metrics import CERAccumulator, greedy_ctc_decode

    if not samples:
        return float("nan")
    dl = DataLoader(samples, batch_size=batch_size, shuffle=False,
                    collate_fn=windowed_collate)
    acc = CERAccumulator()
    was = model.training
    model.eval(); front.eval()
    with torch.no_grad():
        for b in dl:
            x = front(b["inputs"].to(dev))
            with torch.autocast(device_type=dev.type, dtype=torch.bfloat16,
                                enabled=bf16):
                em = model(x)
            em = em.float()
            lens = torch.full((em.shape[1],), em.shape[0], dtype=torch.long)
            tg, tl = b["targets"].numpy(), b["target_lengths"].numpy()
            for n, p in enumerate(greedy_ctc_decode(em, lens,
                                                    blank=cs.null_class)):
                acc.update(LabelData.from_labels(p).text,
                           LabelData.from_labels(tg[: tl[n], n]).text)
    if was:
        model.train(); front.train()
    return acc.cer


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--bands", type=int, default=6,
                    help="RSG output bands; 0 disables RSG (keeps 33)")
    ap.add_argument("--rtn", type=int, default=1)
    ap.add_argument("--acm", type=int, default=1)
    ap.add_argument("--p-ch", type=float, default=0.55)
    ap.add_argument("--window-length", type=int, default=8000)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--weight-decay", type=float, default=1e-5)
    ap.add_argument("--max-steps", type=int, default=60000)
    ap.add_argument("--warmup", type=int, default=2000)
    ap.add_argument("--grad-clip", type=float, default=1.0)
    ap.add_argument("--eval-every", type=int, default=2000)
    ap.add_argument("--log-every", type=int, default=200)
    ap.add_argument("--num-workers", type=int, default=4)
    ap.add_argument("--bf16", action="store_true", default=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    from emg2qwerty.charset import charset as charset_fn

    from .episodes import build_windowed_dataset, windowed_collate
    from .model import build_model
    from .qwerty_data import group_by_user, load_user_sessions
    from .splash import SplashFrontend

    os.makedirs(a.out_dir, exist_ok=True)
    torch.manual_seed(a.seed); np.random.seed(a.seed)
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()

    sess = load_user_sessions(a.repo_root, "generic", a.data_root)
    by_user = group_by_user(sess["train"])
    train_pairs = [(u, p) for u, ps in sorted(by_user.items()) for p in ps]
    test_pairs = sess["test"]
    print(f"[split] {len(by_user)} training users / {len(train_pairs)} "
          f"sessions | {len(test_pairs)} official test sessions", flush=True)

    front = SplashFrontend(n_bands_out=a.bands, use_rtn=bool(a.rtn),
                           use_acm=bool(a.acm), p_ch=a.p_ch).to(dev)
    cfg = {"model": {"version": 1, "frontend": "official",
                     "official_mlp_features": [384],
                     "freq_bins": front.out_freq_bins,
                     "num_bands": 2, "channels_per_band": 16,
                     "d_model": 768,
                     "tds_block_channels": [24, 24, 24, 24],
                     "tds_kernel_width": 32,
                     "use_residual_context": False}}
    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    n_par = sum(p.numel() for p in model.parameters())
    print(f"[model] official TDS, freq_bins={front.out_freq_bins}, "
          f"{n_par/1e6:.2f}M params | RSG={a.bands} RTN={a.rtn} ACM={a.acm}",
          flush=True)

    ds = build_windowed_dataset(train_pairs, train=True,
                                window_length=a.window_length,
                                padding=(1800, 200), raw=False)
    print(f"[data] {len(ds)} training windows of "
          f"{a.window_length/2000:.1f}s", flush=True)
    dl = DataLoader(ds, batch_size=a.batch, shuffle=True, drop_last=True,
                    num_workers=a.num_workers, collate_fn=windowed_collate,
                    persistent_workers=a.num_workers > 0, pin_memory=True)
    eval_test = build_eval_windows(test_pairs)
    print(f"[data] {len(eval_test or [])} monitor windows on the 8 test users",
          flush=True)

    decay, no_decay = [], []
    for n_, p in model.named_parameters():
        (no_decay if p.ndim <= 1 else decay).append(p)
    opt = torch.optim.AdamW(
        [{"params": decay, "weight_decay": a.weight_decay},
         {"params": no_decay, "weight_decay": 0.0}], lr=a.lr,
        betas=(0.9, 0.98))

    def lr_at(s):
        if s < a.warmup:
            return s / max(a.warmup, 1)
        t = (s - a.warmup) / max(1, a.max_steps - a.warmup)
        return 0.5 * (1 + math.cos(math.pi * min(t, 1.0)))

    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_at)

    # PRE-TRAINING SANITY: an untrained model must decode at chance-ish CER.
    c0 = cer_on(model, front, eval_test, cs, dev, a.bf16)
    print(f"[sanity] step 0 test CER {c0:.2f} (untrained; should be ~100)",
          flush=True)

    best, hist, run, t0 = float("inf"), [], [], time.time()
    step = 0
    model.train(); front.train()
    while step < a.max_steps:
        for b in dl:
            x = front(b["inputs"].to(dev))
            with torch.autocast(device_type=dev.type, dtype=torch.bfloat16,
                                enabled=a.bf16):
                em = model(x)
            em = em.float()
            in_len = torch.full((em.shape[1],), em.shape[0],
                                dtype=torch.long, device=dev)
            loss = nn.functional.ctc_loss(
                em, b["targets"].transpose(0, 1).to(dev), in_len,
                b["target_lengths"].to(dev), blank=cs.null_class,
                zero_infinity=True)
            if not torch.isfinite(loss):
                continue
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), a.grad_clip)
            opt.step(); sched.step()
            run.append(float(loss)); step += 1

            if step % a.log_every == 0:
                print(f"step {step}/{a.max_steps} | loss {np.mean(run):.4f} "
                      f"| lr {sched.get_last_lr()[0]:.2e} | "
                      f"{step/(time.time()-t0):.2f} it/s", flush=True)
                run = []
            if step % a.eval_every == 0:
                c = cer_on(model, front, eval_test, cs, dev, a.bf16)
                hist.append({"step": step, "test_cer": c})
                print(f"[val] step {step}: 8-test-user CER {c:.2f}   "
                      f"(plain-baseline reproduction 55.39; SplashNet "
                      f"reports ~36 with this recipe)", flush=True)
                state = {"model": model.state_dict(),
                         "front": front.state_dict(),
                         "cfg": cfg, "args": vars(a), "step": step}
                torch.save(state, os.path.join(a.out_dir, "last.pt"))
                if c < best:
                    best = c
                    torch.save(state, os.path.join(a.out_dir, "best.pt"))
                    print(f"[val] new best {best:.2f} -> best.pt", flush=True)
                json.dump({"args": vars(a), "hist": hist, "best": best},
                          open(os.path.join(a.out_dir, "hist.json"), "w"),
                          indent=1)
            if step >= a.max_steps:
                break
    print(f"[done] best 8-test-user CER {best:.2f}")


if __name__ == "__main__":
    main()
