# Copyright (c) 2026 MyoICL authors. MIT License.
"""Cheapest possible read on the SplashNet normalisation recipe.

Before spending GPU-days retraining, ask the question that costs minutes:
does RTN/RSG change the FROZEN official checkpoint's zero-shot CER at all,
and in which direction?

Expected answer: it should HURT, badly. The published checkpoint was trained
on raw log-spectrograms with a BatchNorm frontend; feeding it causally
z-scored, 6-band features is a distribution its weights have never seen. That
is exactly the lesson Euclidean Alignment taught us -- an alignment that is
part of the training contract cannot be bolted onto a frozen model
(55.39 -> 99.25 there).

So this probe is not "will it help"; it is a NEGATIVE CONTROL that pins down
the claim we will make: SplashNet's -12.6 CER comes from TRAINING WITH the
normalisation, not from the normalisation as a test-time transform. Getting
that distinction on record costs one short job and stops anyone (including
me) from later reporting a retrofit as if it were the method.

It also verifies the module numerically -- shapes, causality, no NaNs -- so
the retraining run does not discover a broken transform after six hours.
"""
from __future__ import annotations

import argparse
from types import SimpleNamespace

import numpy as np
import torch


def check_causality(rtn, dev):
    """Frame t's output must not depend on frames > t."""
    x = torch.randn(40, 1, 2, 16, 6, device=dev)
    a = rtn(x)
    y = x.clone()
    y[25:] = torch.randn_like(y[25:]) * 5.0     # perturb the future only
    b = rtn(y)
    d = (a[:25] - b[:25]).abs().max().item()
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--users", nargs="+", default=["user0", "user1"])
    ap.add_argument("--out", default="/data2/chenyuxiang/runs/splash_probe.json")
    a = ap.parse_args()

    import json

    import yaml
    from emg2qwerty.charset import charset as charset_fn

    from .eval_qwerty import eval_user
    from .model import build_model
    from .pretrained import load_official_backbone
    from .splash import (AggressiveChannelMask, ReduceSpectralGranularity,
                         RollingTimeNorm, SplashFrontend)

    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("=== numerical checks ===")
    rtn = RollingTimeNorm().to(dev)
    d = check_causality(rtn, dev)
    print(f"  causality: max |delta| on frames 0..24 after perturbing 25.. "
          f"= {d:.3e}  {'OK' if d < 1e-5 else 'FAIL -- RTN LEAKS THE FUTURE'}")

    x = torch.randn(200, 2, 2, 16, 33, device=dev) * 3 + 7
    rsg = ReduceSpectralGranularity(6).to(dev)
    y = rsg(x)
    print(f"  RSG: {tuple(x.shape)} -> {tuple(y.shape)}")
    z = rtn(y)
    print(f"  RTN: mean {z.mean().item():+.4f} std {z.std().item():.4f} "
          f"(late frames should be ~0/1) | finite={bool(torch.isfinite(z).all())}")
    late = z[50:]
    print(f"  RTN late frames: mean {late.mean().item():+.4f} "
          f"std {late.std().item():.4f}")
    acm = AggressiveChannelMask().to(dev); acm.train()
    m = acm(z.clone())
    print(f"  ACM: zeroed fraction {float((m == 0).float().mean()):.2f} "
          f"(train) | eval passthrough "
          f"{bool(torch.equal(acm.eval()(z), z))}")

    print("\n=== NEGATIVE CONTROL: retrofit onto the FROZEN official model ===")
    cfg = yaml.safe_load(open(a.config))
    cs = charset_fn()
    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, cfg.get("init_backbone_from"))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    res = {}
    base = {}
    for u in a.users:
        base[u] = eval_user(model, cs, u, a.repo_root, a.data_root, "A", ea,
                            dev).cer
        print(f"  [{u}] unmodified {base[u]:.2f}")
    res["baseline"] = base

    # retrofit RTN only, by wrapping the model's forward input
    orig_forward = model.forward
    front = SplashFrontend(n_bands_out=0, use_rtn=True, use_acm=False).to(dev)
    front.eval()

    def patched(inputs, *args, **kw):
        return orig_forward(front(inputs), *args, **kw)

    model.forward = patched
    rt = {}
    for u in a.users:
        rt[u] = eval_user(model, cs, u, a.repo_root, a.data_root, "A", ea,
                          dev).cer
        print(f"  [{u}] + RTN retrofit {rt[u]:.2f} "
              f"({base[u] - rt[u]:+.2f})")
    res["rtn_retrofit"] = rt
    model.forward = orig_forward

    mb = float(np.mean(list(base.values())))
    mr = float(np.mean(list(rt.values())))
    print(f"\n  mean {mb:.2f} -> {mr:.2f} ({mb - mr:+.2f})")
    if mr > mb + 3:
        print("  ==> AS EXPECTED: retrofitting normalisation onto a model that")
        print("      was trained without it is destructive. SplashNet's -12.6")
        print("      is a TRAINING-time result and must be reproduced by")
        print("      retraining, not by a test-time transform.")
    elif mr < mb - 1:
        print("  ==> SURPRISE: the retrofit helps. Worth a full 8-user run")
        print("      before committing GPU-days to retraining.")
    else:
        print("  ==> roughly neutral; retraining is still the path.")
    json.dump(res, open(a.out, "w"), indent=1)
    print(f"[saved] {a.out}")


if __name__ == "__main__":
    main()
