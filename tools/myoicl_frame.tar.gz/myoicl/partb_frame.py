# Copyright (c) 2026 MyoICL authors. MIT License.
"""Frame-level pseudo-labels: the one route the night's diagnosis points at.

WHAT THE NIGHT ESTABLISHED, in order:
  * window-level filtering cannot work -- a 4 s window holds 20-30 characters
    at ~56 CER, so P(window fully correct) ~ 0; the best window filter reached
    46.80 CER and adapting on it gave +0.07 +- 1.97 over 8 users, i.e. noise;
  * per-CHARACTER confidence is well calibrated -- precision climbs 27.6% ->
    87.3% from the bottom to the top confidence bin, and characters above
    posterior 0.99 are 12.7-23.1 CER, the first pseudo-labels clean enough to
    train on;
  * but segment extraction wasted that, because CTC needs CONTIGUOUS spans and
    confident characters are SCATTERED: runs of three confident characters
    yielded 0.3-0.8% of predictions, a tenth of the per-character rate.

So drop CTC for the adaptation step. Each output frame carries its own
pseudo-label (the argmax) and its own confidence; cross-entropy on a masked
subset of frames needs no contiguity at all. Every confident character can be
used wherever it happens to sit.

TWO CONTROLS, because self-training on your own argmax is exactly the setting
where a method can look like it works while doing nothing:
  random   -- the same number of frames, chosen at random rather than by
              confidence. If this matches the confidence-masked arm, the
              gain has nothing to do with confidence.
  shuffled -- confident frames, but their pseudo-labels permuted. This must
              HURT. If it does not, the loss is not doing what it claims.
"""
from __future__ import annotations

import argparse
import copy
import json
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


def collect_frames(model, samples, cs, dev, batch_size=4):
    """-> list of (window_tensor_cpu, argmax(T,), conf(T,))"""
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate

    out = []
    dl = DataLoader(samples, batch_size=batch_size, shuffle=False,
                    collate_fn=windowed_collate)
    model.eval()
    with torch.no_grad():
        for b in dl:
            x = b["inputs"].to(dev)
            em = model(x).float()                        # (T, N, K)
            p = em.exp()
            top = p.max(-1)
            for n in range(em.shape[1]):
                out.append((b["inputs"][:, n:n + 1].clone(),
                            top.indices[:, n].cpu(),
                            top.values[:, n].cpu()))
    return out


def adapt_frames(model, frames, cs, dev, thr, mode, steps, lr, scope,
                 blank_frac=0.1, seed=0):
    """mode: 'conf' | 'random' | 'shuffled'."""
    rng = np.random.default_rng(seed)
    ps = []
    for name, m in model.named_modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.LayerNorm,
                          nn.GroupNorm)):
            if scope == "inputbn" and "frontend.0" not in name:
                continue
            for p in (m.weight, m.bias):
                if p is not None:
                    p.requires_grad_(True); ps.append(p)
    if not ps:
        return 0, float("nan"), 0
    opt = torch.optim.Adam(ps, lr=lr)

    # precompute the mask per window so every arm uses the same BUDGET
    masks = []
    n_used = 0
    for (_x, arg, conf) in frames:
        nb = arg != cs.null_class
        keep = (conf >= thr) & nb
        k = int(keep.sum())
        if mode == "random":
            # same count, chosen at random among non-blank frames
            idx = torch.where(nb)[0]
            if len(idx) and k:
                sel = idx[torch.as_tensor(
                    rng.choice(len(idx), size=min(k, len(idx)),
                               replace=False))]
                keep = torch.zeros_like(nb)
                keep[sel] = True
            else:
                keep = torch.zeros_like(nb)
        tgt = arg.clone()
        if mode == "shuffled" and k > 1:
            sel = torch.where(keep)[0]
            perm = torch.as_tensor(rng.permutation(len(sel)))
            tgt[sel] = arg[sel][perm]
        # a slice of confident BLANK frames keeps the alignment from drifting
        if blank_frac > 0:
            bl = torch.where((arg == cs.null_class) & (conf >= thr))[0]
            if len(bl):
                nb_take = max(1, int(blank_frac * max(k, 1)))
                sel = bl[torch.as_tensor(
                    rng.choice(len(bl), size=min(nb_take, len(bl)),
                               replace=False))]
                keep = keep.clone(); keep[sel] = True
        masks.append((keep, tgt))
        n_used += int(keep.sum())

    model.train()
    done, losses = 0, []
    order = np.arange(len(frames))
    while done < steps:
        rng.shuffle(order)
        for i in order:
            keep, tgt = masks[int(i)]
            if int(keep.sum()) == 0:
                continue
            x = frames[int(i)][0].to(dev)
            em = model(x).float()[:, 0]                  # (T, K)
            T = min(em.shape[0], keep.shape[0])
            k2 = keep[:T].to(dev)
            if int(k2.sum()) == 0:
                continue
            loss = nn.functional.nll_loss(em[:T][k2],
                                          tgt[:T].to(dev)[k2])
            if not torch.isfinite(loss):
                continue
            opt.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(ps, 1.0)
            opt.step()
            losses.append(float(loss)); done += 1
            if done >= steps:
                break
    model.eval()
    for p in ps:
        p.requires_grad_(False)
    return len(ps), (float(np.mean(losses)) if losses else float("nan")), n_used


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--user", required=True)
    ap.add_argument("--cal-windows", type=int, default=384)
    ap.add_argument("--thr", type=float, default=0.99)
    ap.add_argument("--modes", nargs="+",
                    default=["conf", "random", "shuffled"])
    ap.add_argument("--steps", type=int, default=400)
    ap.add_argument("--lr", type=float, default=3e-5)
    ap.add_argument("--scope", default="inputbn")
    ap.add_argument("--blank-frac", type=float, default=0.1)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import yaml
    from emg2qwerty.charset import charset as charset_fn

    from .eval_qwerty import eval_user
    from .model import build_model
    from .pretrained import load_official_backbone
    from .tta_floor import unlabelled_windows

    cfg = yaml.safe_load(open(a.config))
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()
    torch.manual_seed(a.seed); np.random.seed(a.seed)

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, cfg.get("init_backbone_from"))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    clean = copy.deepcopy(model.state_dict())

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    cal = unlabelled_windows(a.repo_root, a.data_root, a.user, a.cal_windows,
                             ea.window_length, ea.padding, a.seed)
    if not cal:
        raise SystemExit("[FATAL] no windows")
    frames = collect_frames(model, cal, cs, dev)
    print(f"[{a.user}] {len(frames)} windows cached")

    base = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A", ea,
                     dev).cer
    print(f"[{a.user}] unadapted {base:.2f}")

    res = {"args": vars(a), "base": base, "arms": {}}
    for mode in a.modes:
        model.load_state_dict(clean); model.eval()
        npar, loss, nused = adapt_frames(model, frames, cs, dev, a.thr, mode,
                                         a.steps, a.lr, a.scope,
                                         a.blank_frac, a.seed)
        cer = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A", ea,
                        dev).cer
        res["arms"][mode] = {"cer": cer, "gain": base - cer,
                             "frames_used": nused, "loss": loss}
        print(f"[FRAME] {a.user} {mode:>8}: {base:.2f} -> {cer:.2f} "
              f"(gain {base - cer:+.2f}) on {nused} frames", flush=True)
        model.load_state_dict(clean); model.eval()
        json.dump(res, open(a.out, "w"), indent=1)

    c = res["arms"].get("conf", {}).get("gain")
    r = res["arms"].get("random", {}).get("gain")
    s = res["arms"].get("shuffled", {}).get("gain")
    if c is not None and r is not None:
        print(f"\n  conf {c:+.2f} vs random {r:+.2f}: "
              f"{'confidence matters' if c > r + 0.3 else 'NO confidence effect -- the gain, if any, is not from selecting good labels'}")
    if s is not None:
        print(f"  shuffled {s:+.2f}: "
              f"{'hurts as it must' if s < -0.3 else 'does NOT hurt -- the loss is not doing what it claims'}")
    json.dump(res, open(a.out, "w"), indent=1)
    print(f"[saved] {a.out}")


if __name__ == "__main__":
    main()
