# Copyright (c) 2026 MyoICL authors. MIT License.
"""Segment-level pseudo-labels, because window-level filtering cannot work.

THE ARITHMETIC THAT KILLS WINDOW-LEVEL FILTERING. A 4 s window carries 20-30
characters and the generic model runs at ~56 CER. The chance that a whole
window is transcribed correctly is therefore ~0, so no subset of WINDOWS is
clean: measured over 8 users, the best window filter (top-decile confidence)
keeps 10.2% at 46.80 CER. Self-training on 47%-wrong transcripts is what
collapsed the model to 99.85 in the first place.

Individual characters are a different story. Within a bad window some
characters are predicted with posterior ~1 and are almost certainly right. So
this module works at character granularity:

  1. GATE -- align each greedy transcript to the truth with an edit-distance
     alignment, label every predicted character correct/incorrect, and report
     PRECISION AS A FUNCTION OF CONFIDENCE. This single table decides whether
     segment-level pseudo-labels are viable, and it is measured, not assumed.
  2. SEGMENTS -- take maximal runs of consecutive high-confidence emitted
     characters, map them back to input frames through the trunk's receptive
     field (computed empirically, not guessed), and emit (signal slice,
     character run) training pairs.
  3. ADAPT -- CTC on those short, clean pairs; norm affine parameters only.

Also here: a pure-PyTorch CTC prefix beam search with kenlm shallow fusion.
flashlight-text is not installed on this machine and torchaudio's decoder
requires it too, so the plan's LM-as-Teacher decoding has to be built rather
than imported. ~80 lines, and it is validated against greedy before use.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
from collections import defaultdict
from difflib import SequenceMatcher
from types import SimpleNamespace

import numpy as np
import torch
from torch import nn


# ------------------------------------------------------- receptive field --
def receptive_field(model, dev, T_in=1000, n_bands=2, n_ch=16, F=33):
    """Empirical input->output frame reduction. The official TDS encoder uses
    stride-1 convolutions, so T_out = T_in - (RF - 1); guessing a stride ratio
    here would silently misalign every segment we cut."""
    x = torch.zeros(T_in, 1, n_bands, n_ch, F, device=dev)
    with torch.no_grad():
        y = model(x)
    T_out = y.shape[0]
    return T_in - T_out + 1, T_out


# ------------------------------------------------- greedy path with conf --
def greedy_path(em, blank):
    """em (T, K) log-probs -> list of (out_frame, char_id, confidence)."""
    p = em.exp()
    top = p.max(-1)
    arg, conf = top.indices, top.values
    out, prev = [], -1
    for t in range(em.shape[0]):
        a = int(arg[t])
        if a != blank and a != prev:
            out.append((t, a, float(conf[t])))
        prev = a
    return out


# ------------------------------------------------------------ the gate ---
def precision_by_confidence(pred_text, true_text, confs, bins):
    """Which predicted characters are right, binned by confidence.

    Alignment is edit-distance based (SequenceMatcher's matching blocks), so a
    predicted character counts as correct only if it participates in a matched
    run -- insertions and substitutions both count as wrong.
    """
    ok = [False] * len(pred_text)
    for a, _b, size in SequenceMatcher(None, pred_text, true_text,
                                       autojunk=False).get_matching_blocks():
        for i in range(a, a + size):
            if i < len(ok):
                ok[i] = True
    hits = defaultdict(lambda: [0, 0])
    n = min(len(pred_text), len(confs))
    for i in range(n):
        c = confs[i]
        b = int(np.searchsorted(bins, c, side="right")) - 1
        b = max(0, min(b, len(bins) - 2))
        hits[b][0] += int(ok[i])
        hits[b][1] += 1
    return hits


# --------------------------------------------- CTC prefix beam + kenlm ---
def prefix_beam_search(em, blank, id2char, lm=None, lm_weight=1.0,
                       beam=16, prune=1e-3):
    """Pure-PyTorch CTC prefix beam search with optional shallow LM fusion.

    flashlight-text is absent and torchaudio's ctc_decoder needs it, so the
    plan's LM-as-Teacher decoding is implemented here directly. Standard
    Hannun-style prefix beam search: probabilities of a prefix ending in blank
    and ending in a non-blank are tracked separately, and the LM contributes
    only when a new character is appended.
    """
    T, K = em.shape
    probs = em.exp().cpu().numpy()
    # beams: prefix(tuple) -> (p_blank, p_nonblank, lm_state_score)
    beams = {(): (1.0, 0.0, 0.0)}
    for t in range(T):
        pt = probs[t]
        cand = np.where(pt > prune)[0]
        if blank not in cand:
            cand = np.append(cand, blank)
        nxt = defaultdict(lambda: [0.0, 0.0, 0.0])
        for pref, (pb, pnb, lms) in beams.items():
            for k in cand:
                p = float(pt[k])
                if k == blank:
                    e = nxt[pref]
                    e[0] += (pb + pnb) * p
                    e[2] = lms
                    continue
                last = pref[-1] if pref else None
                if k == last:
                    # repeat without blank extends the same character
                    e = nxt[pref]
                    e[1] += pnb * p
                    e[2] = lms
                    npref = pref + (k,)
                    e2 = nxt[npref]
                    e2[1] += pb * p
                    e2[2] = lms + (lm.score_char(npref, id2char) * lm_weight
                                   if lm else 0.0)
                else:
                    npref = pref + (k,)
                    e2 = nxt[npref]
                    e2[1] += (pb + pnb) * p
                    e2[2] = lms + (lm.score_char(npref, id2char) * lm_weight
                                   if lm else 0.0)
        scored = sorted(nxt.items(),
                        key=lambda kv: -(math.log(kv[1][0] + kv[1][1] + 1e-30)
                                         + kv[1][2]))[:beam]
        beams = {k: tuple(v) for k, v in scored}
    best = max(beams.items(),
               key=lambda kv: math.log(kv[1][0] + kv[1][1] + 1e-30) + kv[1][2])
    return list(best[0])


class IncLM:
    """kenlm wrapper giving the incremental log10 prob of the last character.

    Tokenisation is the one solved in jobs 576/578: characters separated by
    spaces with kenlm's own </s> as the word boundary (their decoder.py:
    EOW = "</s>"). Every other separator was 16.6% OOV -- exactly English's
    space rate.
    """

    def __init__(self, path):
        import kenlm

        self.m = kenlm.Model(path)
        self._cache = {}

    @staticmethod
    def _tok(text):
        return " ".join("</s>" if c == " " else c for c in text)

    def score_char(self, prefix_ids, id2char):
        txt = "".join(id2char.get(i, "") for i in prefix_ids)
        if not txt:
            return 0.0
        if txt in self._cache:
            return self._cache[txt]
        prev = self._cache.get(txt[:-1])
        if prev is None:
            prev = self.m.score(self._tok(txt[:-1]), bos=True, eos=False) \
                if len(txt) > 1 else 0.0
            self._cache[txt[:-1]] = prev
        cur = self.m.score(self._tok(txt), bos=True, eos=False)
        self._cache[txt] = cur
        return cur - prev


# ------------------------------------------------------------ segments ---
def segments(path, conf_thr, min_chars, max_gap, rf, T_in):
    """Runs of consecutive high-confidence characters -> (a, b, ids).

    a, b are INPUT-frame bounds derived from output frames through the
    receptive field: output frame t covers input frames [t, t + rf - 1].
    """
    runs, cur = [], []
    for (t, c, q) in path:
        if q < conf_thr:
            if len(cur) >= min_chars:
                runs.append(cur)
            cur = []
            continue
        if cur and t - cur[-1][0] > max_gap:
            if len(cur) >= min_chars:
                runs.append(cur)
            cur = []
        cur.append((t, c, q))
    if len(cur) >= min_chars:
        runs.append(cur)
    out = []
    for r in runs:
        a = max(0, r[0][0])
        b = min(T_in, r[-1][0] + rf)
        if b - a >= rf + 8:
            out.append((a, b, [c for _, c, _ in r]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config",
                    default="configs/qwerty_icl_frozen_official.yaml")
    ap.add_argument("--repo-root",
                    default="/data2/chenyuxiang/code/emg2qwerty")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--user", required=True)
    ap.add_argument("--cal-windows", type=int, default=128)
    ap.add_argument("--conf-thr", type=float, nargs="+",
                    default=[0.9, 0.95, 0.99])
    ap.add_argument("--min-chars", type=int, default=3)
    ap.add_argument("--max-gap", type=int, default=25)
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--lr", type=float, default=3e-5)
    ap.add_argument("--gate-only", action="store_true")
    ap.add_argument("--scope", default="inputbn",
                    choices=["inputbn", "all"],
                    help="which normalisation affine parameters to adapt; "
                         "inputbn (the SpectrogramNorm BatchNorm) matched or "
                         "beat 'all' in every swept cell")
    ap.add_argument("--beam-probe", type=int, default=0,
                    help="run the prefix beam search on this many windows to "
                         "validate it against greedy (0 = skip)")
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    import os

    import yaml
    from emg2qwerty.charset import charset as charset_fn
    from emg2qwerty.data import LabelData
    from torch.utils.data import DataLoader

    from .episodes import windowed_collate
    from .eval_qwerty import eval_user
    from .metrics import CERAccumulator, greedy_ctc_decode
    from .model import build_model
    from .pretrained import load_official_backbone
    from .tta_floor import unlabelled_windows

    cfg = yaml.safe_load(open(a.config))
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    cs = charset_fn()
    np.random.seed(a.seed); torch.manual_seed(a.seed)

    model = build_model(cfg, num_classes=cs.num_classes).to(dev)
    load_official_backbone(model, cfg.get("init_backbone_from"))
    model.eval()
    for p in model.parameters():
        p.requires_grad_(False)
    clean = copy.deepcopy(model.state_dict())

    id2char = {}
    for i in range(cs.num_classes - 1):
        try:
            t = LabelData.from_labels([i]).text
            if len(t) == 1:
                id2char[i] = t
        except Exception:
            pass

    rf, _ = receptive_field(model, dev)
    print(f"[arch] receptive field {rf} input frames per output frame span")

    ea = SimpleNamespace(kshot_window=2000, ctx_seconds=30.0,
                         ctx_source="cross", seg_len=2000, k=4,
                         window_length=8000, padding=[1800, 200],
                         frontend_chunk=4096, chunk_seconds=30.0,
                         overlap_seconds=5.0, bf16=False)

    cal = unlabelled_windows(a.repo_root, a.data_root, a.user, a.cal_windows,
                             ea.window_length, ea.padding, a.seed)
    if not cal:
        raise SystemExit("[FATAL] no windows")

    lm = None
    lm_path = os.path.join(a.repo_root, "models", "lm",
                           "wikitext-103-6gram-charlm.bin")
    if os.path.exists(lm_path):
        try:
            lm = IncLM(lm_path)
            print("[lm] kenlm loaded for shallow fusion")
        except Exception as e:                                # noqa: BLE001
            print(f"[lm] failed: {e}")

    BINS = np.array([0.0, 0.5, 0.7, 0.9, 0.95, 0.99, 1.0001])
    agg = defaultdict(lambda: [0, 0])
    cached = []
    beam_g, beam_b, n_probe = CERAccumulator(), CERAccumulator(), 0

    dl = DataLoader(cal, batch_size=4, shuffle=False,
                    collate_fn=windowed_collate)
    with torch.no_grad():
        for b in dl:
            x = b["inputs"].to(dev)
            em = model(x).float()
            lens = torch.full((em.shape[1],), em.shape[0], dtype=torch.long)
            g = greedy_ctc_decode(em, lens, blank=cs.null_class)
            tg, tl = b["targets"].numpy(), b["target_lengths"].numpy()
            for n in range(em.shape[1]):
                path = greedy_path(em[:, n], cs.null_class)
                ptxt = "".join(id2char.get(c, "") for _, c, _ in path)
                confs = [q for _, _, q in path]
                ttxt = LabelData.from_labels(tg[: tl[n], n]).text
                for k, v in precision_by_confidence(ptxt, ttxt, confs,
                                                    BINS).items():
                    agg[k][0] += v[0]; agg[k][1] += v[1]
                cached.append({"path": path, "true": ttxt,
                               "greedy": LabelData.from_labels(g[n]).text,
                               "x": x[:, n:n + 1].cpu()})
                if n_probe < a.beam_probe:
                    ids = prefix_beam_search(em[:, n], cs.null_class,
                                             id2char, lm, 1.0, beam=12)
                    beam_b.update("".join(id2char.get(i, "") for i in ids),
                                  ttxt)
                    beam_g.update(cached[-1]["greedy"], ttxt)
                    n_probe += 1

    print(f"\n=== THE GATE: character precision vs confidence "
          f"({a.user}) ===")
    print(f"  {'confidence':>14} {'chars':>8} {'precision':>10} "
          f"{'-> pseudo-CER':>14}")
    for k in sorted(agg):
        lo, hi = BINS[k], BINS[k + 1]
        hit, tot = agg[k]
        if not tot:
            continue
        pr = hit / tot
        print(f"  {lo:>6.2f}-{hi:<6.2f} {tot:>8d} {pr:>9.1%} "
              f"{(1 - pr) * 100:>13.1f}")
    tot_all = sum(v[1] for v in agg.values())
    hit_all = sum(v[0] for v in agg.values())
    print(f"  {'ALL':>14} {tot_all:>8d} {hit_all / max(tot_all,1):>9.1%}")

    if a.beam_probe and n_probe:
        print(f"\n[beam] prefix-beam+LM on {n_probe} windows: "
              f"greedy {beam_g.cer:.2f} vs beam {beam_b.cer:.2f} -> "
              f"{'USABLE' if beam_b.cer < beam_g.cer else 'no better'}")

    res = {"args": vars(a), "rf": rf,
           "precision": {int(k): agg[k] for k in agg},
           "beam": ({"greedy": beam_g.cer, "beam": beam_b.cer}
                    if n_probe else None), "segments": {}}

    for thr in a.conf_thr:
        segs, chars, ok = [], 0, 0
        for c in cached:
            T_in = c["x"].shape[0]
            for (s, e, ids) in segments(c["path"], thr, a.min_chars,
                                        a.max_gap, rf, T_in):
                segs.append((c["x"][s:e], ids))
                chars += len(ids)
        res["segments"][str(thr)] = {"n_segments": len(segs),
                                     "n_chars": chars}
        print(f"[seg] thr {thr}: {len(segs)} segments, {chars} characters "
              f"({chars / max(tot_all,1):.1%} of all predicted characters)")
        if a.gate_only or not segs:
            continue

        # ---- SEGMENT-LEVEL ADAPTATION --------------------------------
        # Batch size 1 on purpose: segments have different lengths and the
        # trunk takes no length argument, so padding a batch would feed the
        # CTC loss outputs computed over padding. One segment per step is
        # slower and unambiguous, which is the right trade for a number that
        # has to be trusted.
        model.load_state_dict(clean); model.eval()
        before = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A",
                           ea, dev).cer
        ps = []
        for name, m in model.named_modules():
            if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.LayerNorm,
                              nn.GroupNorm)):
                if a.scope == "inputbn" and "frontend.0" not in name:
                    continue
                for p in (m.weight, m.bias):
                    if p is not None:
                        p.requires_grad_(True); ps.append(p)
        opt = torch.optim.Adam(ps, lr=a.lr)
        model.train()
        done, losses = 0, []
        while done < a.steps:
            for idx in np.random.permutation(len(segs)):
                xs, ids = segs[int(idx)]
                if not ids:
                    continue
                xb = xs.to(dev)
                em2 = model(xb).float()
                T_out = em2.shape[0]
                if T_out < len(ids) + 1:
                    continue                      # CTC needs room for blanks
                tgt = torch.tensor([ids], dtype=torch.long, device=dev)
                loss = nn.functional.ctc_loss(
                    em2, tgt,
                    torch.tensor([T_out], device=dev),
                    torch.tensor([len(ids)], device=dev),
                    blank=cs.null_class, zero_infinity=True)
                if not torch.isfinite(loss):
                    continue
                opt.zero_grad(set_to_none=True)
                loss.backward()
                nn.utils.clip_grad_norm_(ps, 1.0)
                opt.step()
                losses.append(float(loss)); done += 1
                if done >= a.steps:
                    break
        model.eval()
        after = eval_user(model, cs, a.user, a.repo_root, a.data_root, "A",
                          ea, dev).cer
        res["segments"][str(thr)].update(
            {"before": before, "after": after, "gain": before - after,
             "steps": done, "scope": a.scope, "lr": a.lr,
             "mean_loss": float(np.mean(losses)) if losses else None})
        print(f"[SEG-ADAPT] {a.user} thr {thr}: {before:.2f} -> {after:.2f} "
              f"(gain {before - after:+.2f}) on {len(segs)} segments / "
              f"{chars} chars, ZERO labels", flush=True)
        for p in ps:
            p.requires_grad_(False)
        model.load_state_dict(clean); model.eval()
        json.dump(res, open(a.out, "w"), indent=1)

    json.dump(res, open(a.out, "w"), indent=1)
    print(f"[saved] {a.out}")


if __name__ == "__main__":
    main()
